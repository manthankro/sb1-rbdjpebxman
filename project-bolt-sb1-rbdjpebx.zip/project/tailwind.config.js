/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: { 0: '#060a10', 1: '#0a1119', 2: '#0f1822' },
        surface: { DEFAULT: '#111c28', 2: '#16232f' },
        edge: { DEFAULT: '#1e2f3f', strong: '#2a4257' },
        ink: { DEFAULT: '#e6f0f5', muted: '#8aa0b0', dim: '#5f7686' },
        cyber: { cyan: '#22d3ee', cyanDim: '#0e7490', green: '#34d399', greenDim: '#047857' },
        risk: { low: '#34d399', med: '#fbbf24', high: '#fb923c', crit: '#f87171' },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 24px rgba(34,211,238,0.18)',
        glowGreen: '0 0 24px rgba(52,211,153,0.18)',
      },
    },
  },
  plugins: [],
};
