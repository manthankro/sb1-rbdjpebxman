import { useEffect } from 'react';
import { useHashRoute, navigateTo } from '@/lib/router';
import { useAuth } from '@/lib/auth';
import { AppLayout } from '@/components/Layout';
import { LandingPage } from '@/pages/LandingPage';
import { AuthPages } from '@/pages/AuthPages';
import { DashboardPage } from '@/pages/DashboardPage';
import { ScenariosPage } from '@/pages/ScenariosPage';
import { SimulationPage } from '@/pages/SimulationPage';
import { ResultPage } from '@/pages/ResultPage';
import { ReportPage } from '@/pages/ReportPage';
import { HistoryPage } from '@/pages/HistoryPage';
import { AdminPage } from '@/pages/AdminPage';

export default function App() {
  const [route] = useHashRoute();
  const { user, loading } = useAuth();

  const seg = route.split('/').filter(Boolean);
  const top = seg[0] ?? '';

  // Redirect signed-in users away from public pages (login/register/landing).
  // Done in an effect, not during render, to avoid React state warnings.
  useEffect(() => {
    if (user && (top === 'login' || top === 'register' || top === '' || top === '/')) {
      navigateTo('/dashboard');
    }
  }, [user, top]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-bg-0 text-ink-muted text-sm">
        Loading CyberShield…
      </div>
    );
  }

  // Public routes.
  if (top === 'login' || top === 'register') {
    if (user) return null; // effect will redirect
    return <AuthPages mode={top === 'login' ? 'login' : 'register'} />;
  }

  if (top === '' || top === '/') {
    if (user) return null;
    return <LandingPage />;
  }

  // Auth required for everything else.
  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-bg-0 gap-4">
        <p className="text-ink-muted text-sm">Please sign in to continue.</p>
        <div className="flex gap-2">
          <button onClick={() => navigateTo('/login')} className="rounded-lg bg-cyber-cyan text-bg-0 px-4 py-2 text-sm font-medium">Login</button>
          <button onClick={() => navigateTo('/register')} className="rounded-lg border border-edge-strong px-4 py-2 text-sm text-ink">Register</button>
        </div>
      </div>
    );
  }

  let page: React.ReactNode;
  switch (top) {
    case 'dashboard': page = <DashboardPage />; break;
    case 'scenarios': page = <ScenariosPage />; break;
    case 'simulation': page = <SimulationPage />; break;
    case 'result': page = <ResultPage />; break;
    case 'report': page = <ReportPage />; break;
    case 'history': page = <HistoryPage />; break;
    case 'admin': page = <AdminPage />; break;
    default: page = <NotFoundPage />;
  }

  return <AppLayout>{page}</AppLayout>;
}

function NotFoundPage() {
  return (
    <div className="py-20 text-center">
      <p className="text-4xl font-bold text-cyber-cyan font-mono-pro">404</p>
      <p className="mt-3 text-sm text-ink-muted">This page doesn't exist.</p>
      <button onClick={() => navigateTo('/dashboard')} className="mt-5 rounded-lg bg-cyber-cyan text-bg-0 px-4 py-2 text-sm font-medium hover:bg-cyan-300">
        Back to dashboard
      </button>
    </div>
  );
}
