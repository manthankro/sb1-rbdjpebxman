import type { ReactNode } from 'react';

// Lightweight dependency-free charts (radial gauge + bar/line). We avoid
// pulling in a chart library to keep the bundle small and the code easy to
// explain during the viva.

export function RadialGauge({
  value,
  label,
  sublabel,
  color = '#22d3ee',
  size = 180,
}: {
  value: number; // 0-100
  label: string;
  sublabel?: string;
  color?: string;
  size?: number;
}) {
  const stroke = 12;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, value));
  const offset = c - (pct / 100) * c;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="absolute inset-0 -rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#1e2f3f" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 0.8s ease' }}
        />
      </svg>
      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center">
        <span className="font-mono-pro text-3xl font-semibold text-ink">{Math.round(pct)}</span>
        <span className="text-xs text-ink-muted mt-0.5">{label}</span>
        {sublabel && <span className="text-[11px] text-ink-dim mt-0.5">{sublabel}</span>}
      </div>
    </div>
  );
}

export function BarChart({
  data,
  height = 160,
  color = '#22d3ee',
}: {
  data: { label: string; value: number }[];
  height?: number;
  color?: string;
}) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="flex items-end gap-3" style={{ height }}>
      {data.map((d, i) => (
        <div key={i} className="flex flex-1 flex-col items-center justify-end gap-2 min-w-0">
          <div className="text-xs font-mono-pro text-ink-muted">{d.value}</div>
          <div
            className="w-full rounded-t-md transition-all duration-700"
            style={{ height: `${(d.value / max) * (height - 40)}px`, background: color, minHeight: 4, opacity: 0.85 }}
            title={`${d.label}: ${d.value}`}
          />
          <div className="text-[11px] text-ink-dim truncate w-full text-center" title={d.label}>
            {d.label}
          </div>
        </div>
      ))}
    </div>
  );
}

export function LineChart({
  points,
  height = 160,
  color = '#34d399',
  yMax = 100,
}: {
  points: { label: string; value: number }[];
  height?: number;
  color?: string;
  yMax?: number;
}) {
  const width = 320;
  const pad = 24;
  const innerW = width - pad * 2;
  const innerH = height - pad * 2;
  const n = Math.max(1, points.length);
  const x = (i: number) => pad + (i / (n - 1 || 1)) * innerW;
  const y = (v: number) => pad + innerH - (Math.max(0, Math.min(yMax, v)) / yMax) * innerH;
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${x(i)} ${y(p.value)}`).join(' ');
  const area = `${path} L ${x(n - 1)} ${pad + innerH} L ${x(0)} ${pad + innerH} Z`;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ height }}>
      <defs>
        <linearGradient id="lc-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.30" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0, 0.5, 1].map((t) => (
        <line key={t} x1={pad} x2={width - pad} y1={pad + innerH * t} y2={pad + innerH * t} stroke="#1e2f3f" strokeWidth="1" />
      ))}
      {points.length > 1 && <path d={area} fill="url(#lc-grad)" />}
      {points.length > 1 && <path d={path} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />}
      {points.map((p, i) => (
        <g key={i}>
          <circle cx={x(i)} cy={y(p.value)} r="3" fill={color} />
          <text x={x(i)} y={height - 6} textAnchor="middle" className="fill-[#5f7686]" style={{ fontSize: 9 }}>
            {p.label}
          </text>
        </g>
      ))}
      {points.length === 1 && (
        <text x={width / 2} y={height / 2} textAnchor="middle" className="fill-[#5f7686]" style={{ fontSize: 11 }}>
          Not enough data yet
        </text>
      )}
    </svg>
  );
}

export function StatCard({ label, value, sub, accent = '#22d3ee', icon }: { label: string; value: ReactNode; sub?: string; accent?: string; icon?: ReactNode }) {
  return (
    <div className="rounded-xl border border-edge bg-surface p-4 transition-colors hover:border-edge-strong">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wider text-ink-dim">{label}</span>
        {icon && <span style={{ color: accent }}>{icon}</span>}
      </div>
      <div className="mt-2 font-mono-pro text-2xl font-semibold text-ink">{value}</div>
      {sub && <div className="mt-1 text-xs text-ink-muted">{sub}</div>}
    </div>
  );
}
