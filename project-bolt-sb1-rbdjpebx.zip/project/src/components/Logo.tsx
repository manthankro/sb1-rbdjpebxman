import { Shield } from 'lucide-react';

// CyberShield logo lockup — a shield icon with neon cyan glow, plus the
// wordmark. Used in the header and on the landing hero.
export function Logo({ size = 28, withText = true }: { size?: number; withText?: boolean }) {
  return (
    <div className="flex items-center gap-2.5 select-none">
      <span
        className="relative inline-flex items-center justify-center rounded-lg"
        style={{ width: size + 8, height: size + 8 }}
      >
        <span
          className="absolute inset-0 rounded-lg"
          style={{ background: 'radial-gradient(circle, rgba(34,211,238,0.25), transparent 70%)' }}
        />
        <Shield size={size} className="relative text-cyber-cyan" strokeWidth={2.2} />
      </span>
      {withText && (
        <span className="font-mono-pro text-lg font-semibold tracking-tight text-ink">
          Cyber<span className="text-cyber-cyan">Shield</span>
        </span>
      )}
    </div>
  );
}
