import type { ResultLevel } from '@/lib/types';

// Maps a result level (or numeric risk score) to a color + label, used across
// the dashboard, simulation, and result pages for consistent risk indication.
const LEVEL_STYLES: Record<ResultLevel, { color: string; bg: string; border: string; dot: string }> = {
  'Excellent': { color: '#34d399', bg: 'rgba(52,211,153,0.10)', border: 'rgba(52,211,153,0.35)', dot: '#34d399' },
  'Good': { color: '#a3e635', bg: 'rgba(163,230,53,0.10)', border: 'rgba(163,230,53,0.30)', dot: '#a3e635' },
  'Moderate Risk': { color: '#fbbf24', bg: 'rgba(251,191,36,0.10)', border: 'rgba(251,191,36,0.35)', dot: '#fbbf24' },
  'High Risk': { color: '#fb923c', bg: 'rgba(251,146,60,0.12)', border: 'rgba(251,146,60,0.38)', dot: '#fb923c' },
  'Critical Risk': { color: '#f87171', bg: 'rgba(248,113,113,0.12)', border: 'rgba(248,113,113,0.40)', dot: '#f87171' },
};

export function riskStyle(level: ResultLevel) {
  return LEVEL_STYLES[level];
}

export function levelFromScore(score: number): ResultLevel {
  if (score <= 20) return 'Excellent';
  if (score <= 40) return 'Good';
  if (score <= 60) return 'Moderate Risk';
  if (score <= 80) return 'High Risk';
  return 'Critical Risk';
}

export function RiskBadge({ level, score, size = 'md' }: { level: ResultLevel; score?: number; size?: 'sm' | 'md' }) {
  const s = LEVEL_STYLES[level];
  const pad = size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-medium ${pad}`}
      style={{ color: s.color, background: s.bg, borderColor: s.border }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: s.dot }} />
      {level}
      {score !== undefined && <span className="opacity-70">· {score}</span>}
    </span>
  );
}

export function RiskBar({ score }: { score: number }) {
  const level = levelFromScore(score);
  const s = LEVEL_STYLES[level];
  return (
    <div className="h-2 w-full rounded-full bg-edge/60 overflow-hidden">
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${Math.max(4, Math.min(100, score))}%`, background: s.color }}
      />
    </div>
  );
}
