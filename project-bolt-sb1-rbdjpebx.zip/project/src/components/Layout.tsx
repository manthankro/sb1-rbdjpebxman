import type { ReactNode } from 'react';
import { useAuth } from '@/lib/auth';
import { navigateTo, useHashRoute } from '@/lib/router';
import { Logo } from './Logo';
import { LogOut, LayoutDashboard, ShieldCheck, History, PanelLeft, UserCircle } from 'lucide-react';

interface NavItem {
  to: string;
  label: string;
  icon: ReactNode;
}

export function AppLayout({ children }: { children: ReactNode }) {
  const { user, profile, signOut } = useAuth();
  const [route] = useHashRoute();
  const isAdmin = profile?.role === 'admin';
  const currentHash = route;

  const nav: NavItem[] = [
    { to: '/dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
    { to: '/scenarios', label: 'Scenarios', icon: <ShieldCheck size={18} /> },
    { to: '/history', label: 'History', icon: <History size={18} /> },
  ];
  if (isAdmin) nav.push({ to: '/admin', label: 'Admin', icon: <PanelLeft size={18} /> });

  return (
    <div className="min-h-screen flex flex-col bg-bg-0">
      <header className="sticky top-0 z-30 border-b border-edge bg-bg-1/90 backdrop-blur">
        <div className="mx-auto max-w-6xl px-4 h-14 flex items-center justify-between gap-4">
          <button onClick={() => navigateTo(profile ? '/dashboard' : '/')} className="flex items-center">
            <Logo size={24} />
          </button>

          {user && (
            <nav className="hidden md:flex items-center gap-1">
              {nav.map((item) => {
                const active = route.startsWith(item.to);
                return (
                  <button
                    key={item.to}
                    onClick={() => navigateTo(item.to)}
                    className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm transition-colors ${
                      active ? 'bg-surface text-cyber-cyan' : 'text-ink-muted hover:text-ink hover:bg-surface/60'
                    }`}
                  >
                    {item.icon}
                    {item.label}
                  </button>
                );
              })}
            </nav>
          )}

          <div className="flex items-center gap-3">
            {user ? (
              <>
                <div className="hidden sm:flex items-center gap-2 text-sm text-ink-muted">
                  <UserCircle size={18} className="text-cyber-cyan" />
                  <span className="truncate max-w-[140px]">{profile?.full_name || 'User'}</span>
                  {isAdmin && (
                    <span className="rounded bg-cyber-cyanDim/30 px-1.5 py-0.5 text-[10px] font-medium text-cyber-cyan">ADMIN</span>
                  )}
                </div>
                <button
                  onClick={async () => {
                    await signOut();
                    navigateTo('/');
                  }}
                  className="flex items-center gap-1.5 rounded-lg border border-edge px-2.5 py-1.5 text-sm text-ink-muted hover:text-risk-crit hover:border-risk-crit/40 transition-colors"
                  title="Sign out"
                >
                  <LogOut size={16} />
                  <span className="hidden sm:inline">Sign out</span>
                </button>
              </>
            ) : (
              <>
                <button onClick={() => navigateTo('/login')} className="text-sm text-ink-muted hover:text-ink px-2 py-1.5">
                  Login
                </button>
                <button
                  onClick={() => navigateTo('/register')}
                  className="rounded-lg bg-cyber-cyan text-bg-0 px-3 py-1.5 text-sm font-medium hover:bg-cyan-300 transition-colors"
                >
                  Register
                </button>
              </>
            )}
          </div>
        </div>

        {/* Mobile nav row */}
        {user && (
          <div className="md:hidden border-t border-edge px-4 py-2 flex items-center gap-1 overflow-x-auto">
            {nav.map((item) => {
              const active = currentHash.startsWith(item.to);
              return (
                <button
                  key={item.to}
                  onClick={() => navigateTo(item.to)}
                  className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs whitespace-nowrap ${
                    active ? 'bg-surface text-cyber-cyan' : 'text-ink-muted'
                  }`}
                >
                  {item.icon}
                  {item.label}
                </button>
              );
            })}
          </div>
        )}
      </header>

      <main className="flex-1 mx-auto w-full max-w-6xl px-4 py-6">{children}</main>

      <footer className="border-t border-edge bg-bg-1">
        <div className="mx-auto max-w-6xl px-4 py-4 text-xs text-ink-dim flex flex-col sm:flex-row justify-between gap-2">
          <span>CyberShield — Educational simulator. All scenarios & identities are fictional.</span>
          <span className="font-mono-pro">BCS ASRP · AI-Based Adaptive Scam Conversation Simulator</span>
        </div>
      </footer>
    </div>
  );
}
