import { useEffect, useState } from 'react';
import { useHashRoute, navigateTo } from '@/lib/router';
import { fetchSession, fetchScenario, fetchResponses, fetchRecommendations } from '@/lib/data';
import type { Session, Scenario, ResponseRow, Recommendation } from '@/lib/types';
import { RadialGauge, StatCard } from '@/components/Charts';
import { RiskBadge } from '@/components/Risk';
import { CheckCircle2, AlertOctagon, Lightbulb, ArrowRight, FileText, Loader2 } from 'lucide-react';

export function ResultPage() {
  const [route] = useHashRoute();
  const sessionId = route.split('/')[2];

  const [session, setSession] = useState<Session | null>(null);
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [responses, setResponses] = useState<ResponseRow[]>([]);
  const [recs, setRecs] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!sessionId) return;
    (async () => {
      try {
        const s = await fetchSession(sessionId);
        if (!s) { setLoading(false); return; }
        setSession(s);
        const sc = await fetchScenario(s.scenario_id);
        setScenario(sc);
        const [rs, rc] = await Promise.all([fetchResponses(sessionId), fetchRecommendations(sessionId)]);
        setResponses(rs);
        setRecs(rc);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Failed to load your result.');
      } finally {
        setLoading(false);
      }
    })();
  }, [sessionId]);

  if (loading) return <div className="py-20 text-center text-ink-muted flex items-center justify-center gap-2"><Loader2 size={18} className="animate-spin" /> Loading your report…</div>;
  if (error) return <div className="py-20 text-center"><p className="text-sm text-risk-crit">{error}</p><button onClick={() => navigateTo('/dashboard')} className="mt-4 rounded-lg border border-edge px-4 py-2 text-sm text-ink-muted hover:text-ink">Back to dashboard</button></div>;
  if (!session) return <div className="py-20 text-center text-ink-muted">Session not found.</div>;

  const gaugeColor = session.awareness_score >= 60 ? '#34d399' : session.awareness_score >= 40 ? '#fbbf24' : '#f87171';
  const risky = responses.filter((r) => r.risk_points > 0);
  const safe = responses.filter((r) => r.risk_points <= 0);

  return (
    <div className="space-y-6">
      <div>
        <div className="text-sm text-ink-muted">{scenario?.category}</div>
        <h1 className="text-2xl font-semibold text-ink">{scenario?.title ?? 'Scenario'} — Result</h1>
      </div>

      {/* Score summary */}
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-xl border border-edge bg-surface p-5 flex flex-col">
          <h3 className="text-sm text-ink-muted text-center">Awareness</h3>
          <div className="mt-4 flex justify-center">
            <RadialGauge value={session.awareness_score} label="Awareness" sublabel="100 - risk score" color={gaugeColor} />
          </div>
          <div className="mt-3 flex justify-center"><RiskBadge level={session.result_level} score={session.final_score} /></div>
        </div>

        <div className="lg:col-span-2 grid gap-4 sm:grid-cols-2">
          <StatCard label="Final risk score" value={`${session.final_score}/100`} sub={`Raw: ${session.raw_score}`} icon={<AlertOctagon size={18} />} accent="#fb923c" />
          <StatCard label="Awareness score" value={`${Math.round(session.awareness_score)}/100`} sub="Higher is better" icon={<CheckCircle2 size={18} />} accent="#34d399" />
          <StatCard label="Safe decisions" value={session.safe_decisions} sub={safe.length ? `${safe.length} recorded` : '—'} icon={<CheckCircle2 size={18} />} accent="#34d399" />
          <StatCard label="Risky decisions" value={session.risky_decisions} sub={risky.length ? `${risky.length} recorded` : 'None'} icon={<AlertOctagon size={18} />} accent="#fb923c" />
        </div>
      </div>

      {/* Recommendations */}
      <div className="rounded-xl border border-edge bg-surface">
        <div className="border-b border-edge px-5 py-3 flex items-center gap-2">
          <Lightbulb size={18} className="text-cyber-cyan" />
          <h3 className="font-semibold text-ink">Personalized recommendations</h3>
        </div>
        <ul className="divide-y divide-edge">
          {recs.length === 0 ? (
            <li className="px-5 py-4 text-sm text-ink-muted">No recommendations generated.</li>
          ) : (
            recs.map((r) => (
              <li key={r.id} className="px-5 py-3 flex items-start gap-3">
                <span
                  className={`mt-1 h-2 w-2 rounded-full shrink-0 ${
                    r.priority === 'high' ? 'bg-risk-high' : r.priority === 'medium' ? 'bg-risk-med' : 'bg-cyber-green'
                  }`}
                />
                <span className="text-sm text-ink">{r.recommendation}</span>
              </li>
            ))
          )}
        </ul>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={() => navigateTo(`/report/${session.id}`)}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-cyber-cyan text-bg-0 px-5 py-2.5 font-medium hover:bg-cyan-300"
        >
          <FileText size={18} /> View detailed report
        </button>
        <button
          onClick={() => navigateTo('/scenarios')}
          className="inline-flex items-center justify-center gap-2 rounded-lg border border-edge-strong px-5 py-2.5 font-medium text-ink hover:bg-surface"
        >
          Try another scenario <ArrowRight size={16} />
        </button>
        <button
          onClick={() => navigateTo('/dashboard')}
          className="inline-flex items-center justify-center gap-2 rounded-lg border border-edge px-5 py-2.5 font-medium text-ink-muted hover:text-ink"
        >
          Back to dashboard
        </button>
      </div>
    </div>
  );
}
