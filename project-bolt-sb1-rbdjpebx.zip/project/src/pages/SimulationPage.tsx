import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useAuth } from '@/lib/auth';
import { navigateTo, useHashRoute } from '@/lib/router';
import {
  fetchScenario,
  fetchScenarioGraph,
  createSession,
  appendResponse,
  completeSession,
  insertRecommendations,
} from '@/lib/data';
import { analyzeResponse } from '@/lib/analyzer';
import { computeScore } from '@/lib/scoring';
import { generateRecommendations } from '@/lib/recommendations';
import type { Scenario, Node, Choice, ResponseRow } from '@/lib/types';
import { RiskBar, levelFromScore } from '@/components/Risk';
import { AlertTriangle, ShieldAlert, Send, CornerDownLeft, User, Bot, Cpu, Loader2 } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'scammer' | 'student' | 'system';
  text: string;
  explanation?: string;
  riskPoints?: number;
}

export function SimulationPage() {
  const [route] = useHashRoute();
  const scenarioId = route.split('/')[2];
  const { user } = useAuth();

  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [choicesByNode, setChoicesByNode] = useState<Record<string, Choice[]>>({});
  const [nodeMap, setNodeMap] = useState<Record<string, Node>>({});
  const [currentNode, setCurrentNode] = useState<Node | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [riskPoints, setRiskPoints] = useState<number[]>([]);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [freeText, setFreeText] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [finishing, setFinishing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Refs to track accumulating state — avoids stale closures in setTimeout.
  const riskPointsRef = useRef<number[]>([]);
  const responsesRef = useRef<ResponseRow[]>([]);
  const sessionIdRef = useRef<string | null>(null);
  const nodeMapRef = useRef<Record<string, Node>>({});

  // Load scenario graph.
  useEffect(() => {
    if (!scenarioId) {
      setError('No scenario selected. Go back and pick one.');
      setLoading(false);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const sc = await fetchScenario(scenarioId);
        if (cancelled) return;
        if (!sc) {
          setError('Scenario not found.');
          setLoading(false);
          return;
        }
        setScenario(sc);
        const { nodes: ns, choices: cs, startNode } = await fetchScenarioGraph(scenarioId);
        if (cancelled) return;
        const map: Record<string, Node> = {};
        ns.forEach((n) => (map[n.id] = n));
        setNodeMap(map);
        nodeMapRef.current = map;
        const cMap: Record<string, Choice[]> = {};
        cs.forEach((c) => {
          (cMap[c.node_id] ??= []).push(c);
        });
        setChoicesByNode(cMap);
        if (startNode) {
          setCurrentNode(startNode);
          setMessages([{ id: startNode.id, sender: startNode.sender, text: startNode.message }]);
        } else {
          setError('This scenario has no starting point.');
        }
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Failed to load scenario.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [scenarioId]);

  // Create session once graph is ready.
  useEffect(() => {
    if (!scenario || sessionId || !user) return;
    createSession(scenario.id, scenario.difficulty)
      .then((s) => {
        setSessionId(s.id);
        sessionIdRef.current = s.id;
      })
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed to start session.'));
  }, [scenario, sessionId, user]);

  // Auto-scroll on new messages.
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const currentScore = useMemo(() => computeScore(riskPoints), [riskPoints]);

  const pushMessage = useCallback((m: ChatMessage) => {
    setMessages((prev) => [...prev, m]);
  }, []);

  const finishSession = useCallback(
    async (allPoints: number[], allResponses: ResponseRow[]) => {
      const sid = sessionIdRef.current;
      if (!sid) return;
      setFinishing(true);
      try {
        const score = computeScore(allPoints);
        const session = await completeSession(sid, {
          raw_score: score.raw_score,
          final_score: score.final_score,
          awareness_score: score.awareness_score,
          result_level: score.result_level,
          safe_decisions: score.safe_decisions,
          risky_decisions: score.risky_decisions,
        });
        const recs = generateRecommendations(
          score.result_level,
          allResponses.map((r) => ({ risk_points: r.risk_points, explanation: r.explanation, free_text: r.free_text }))
        );
        try {
          await insertRecommendations(sid, recs);
        } catch (e) {
          console.warn('insertRecommendations', e);
        }
        navigateTo(`/result/${session.id}`);
      } catch (e) {
        setFinishing(false);
        setError(e instanceof Error ? e.message : 'Failed to save your results.');
      }
    },
    []
  );

  const advanceTo = useCallback(
    (node: Node) => {
      setCurrentNode(node);
      pushMessage({ id: `${node.id}-${Date.now()}`, sender: node.sender, text: node.message });
    },
    [pushMessage]
  );

  const handleChoice = useCallback(
    async (choice: Choice) => {
      if (!currentNode) return;
      const sid = sessionIdRef.current;
      if (!sid) {
        setError('Session is still being created. Please try again in a moment.');
        return;
      }
      setBusy(true);
      try {
        pushMessage({
          id: `s-${choice.id}-${Date.now()}`,
          sender: 'student',
          text: choice.choice_text,
          explanation: choice.explanation,
          riskPoints: choice.risk_points,
        });

        const resp = await appendResponse({
          session_id: sid,
          node_id: currentNode.id,
          choice_id: choice.id,
          choice_code: choice.code,
          free_text: null,
          risk_points: choice.risk_points,
          explanation: choice.explanation,
          ai_analysis: null,
        });

        const newPoints = [...riskPointsRef.current, choice.risk_points];
        const newResponses = [...responsesRef.current, resp];
        riskPointsRef.current = newPoints;
        responsesRef.current = newResponses;
        setRiskPoints(newPoints);

        const nextId = choice.next_node_id ?? currentNode.next_node_id;
        const next = nextId ? nodeMapRef.current[nextId] : null;
        if (next) {
          setTimeout(() => {
            advanceTo(next);
            if (next.is_end) {
              finishSession(newPoints, newResponses);
            }
          }, 350);
        } else {
          finishSession(newPoints, newResponses);
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Failed to record response.');
      } finally {
        setBusy(false);
      }
    },
    [currentNode, pushMessage, advanceTo, finishSession]
  );

  const handleFreeText = useCallback(async () => {
    if (!currentNode || !freeText.trim()) return;
    const sid = sessionIdRef.current;
    if (!sid) {
      setError('Session is still being created. Please try again in a moment.');
      return;
    }
    setBusy(true);
    try {
      const analysis = analyzeResponse(freeText);
      pushMessage({
        id: `ft-${Date.now()}`,
        sender: 'student',
        text: freeText.trim(),
        explanation: `AI analysis: ${analysis.intent} — ${analysis.explanation}`,
        riskPoints: analysis.risk_points,
      });

      const resp = await appendResponse({
        session_id: sid,
        node_id: currentNode.id,
        choice_id: null,
        choice_code: null,
        free_text: freeText.trim(),
        risk_points: analysis.risk_points,
        explanation: analysis.explanation,
        ai_analysis: analysis,
      });

      const newPoints = [...riskPointsRef.current, analysis.risk_points];
      const newResponses = [...responsesRef.current, resp];
      riskPointsRef.current = newPoints;
      responsesRef.current = newResponses;
      setRiskPoints(newPoints);
      setFreeText('');

      const nextId = currentNode.next_node_id;
      const next = nextId ? nodeMapRef.current[nextId] : null;
      if (next) {
        setTimeout(() => {
          advanceTo(next);
          if (next.is_end) {
            finishSession(newPoints, newResponses);
          }
        }, 350);
      } else {
        finishSession(newPoints, newResponses);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to analyze response.');
    } finally {
      setBusy(false);
    }
  }, [currentNode, freeText, pushMessage, advanceTo, finishSession]);

  if (loading) return <div className="py-20 text-center text-ink-muted flex items-center justify-center gap-2"><Loader2 size={18} className="animate-spin" /> Loading scenario…</div>;
  if (error) return <ErrorBox message={error} />;
  if (!scenario || !currentNode) return <div className="py-20 text-center text-ink-muted">Scenario unavailable.</div>;

  const choices = choicesByNode[currentNode.id] ?? [];
  const isFreeText = currentNode.kind === 'free_text';
  const isEnd = currentNode.is_end;
  const sessionReady = !!sessionId;

  return (
    <div className="flex flex-col h-[calc(100vh-7rem)]">
      {/* Header */}
      <div className="rounded-t-xl border border-edge bg-surface px-4 py-3 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="font-semibold text-ink truncate">{scenario.title}</div>
          <div className="text-xs text-ink-dim">{scenario.category} · {scenario.difficulty}</div>
        </div>
        <div className="w-40 sm:w-56 shrink-0">
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="text-ink-muted">Risk</span>
            <span className="font-mono-pro" style={{ color: levelFromScore(currentScore.final_score) === 'Critical Risk' ? '#f87171' : levelFromScore(currentScore.final_score) === 'High Risk' ? '#fb923c' : levelFromScore(currentScore.final_score) === 'Moderate Risk' ? '#fbbf24' : '#34d399' }}>
              {currentScore.final_score}/100
            </span>
          </div>
          <RiskBar score={currentScore.final_score} />
        </div>
      </div>

      {/* Chat area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto border-x border-edge bg-bg-1 px-3 sm:px-5 py-4 space-y-3">
        {messages.map((m) => (
          <ChatBubble key={m.id} message={m} />
        ))}
        {busy && (
          <div className="flex items-center gap-2 text-ink-dim text-xs">
            <span className="typing-dot" /><span className="typing-dot" /><span className="typing-dot" />
          </div>
        )}
      </div>

      {/* Response area */}
      <div className="rounded-b-xl border border-edge bg-surface px-3 sm:px-5 py-4">
        {!sessionReady && !isEnd && (
          <div className="text-center py-2 text-sm text-ink-muted flex items-center justify-center gap-2">
            <Loader2 size={14} className="animate-spin" /> Starting session…
          </div>
        )}

        {isEnd ? (
          <div className="text-center py-2">
            <p className="text-sm text-ink-muted flex items-center justify-center gap-2">
              {finishing ? <><Loader2 size={14} className="animate-spin" /> Calculating your report…</> : 'This scenario has ended. Calculating your report…'}
            </p>
          </div>
        ) : isFreeText ? (
          <div>
            <label className="flex items-center gap-1.5 text-xs text-ink-muted mb-2">
              <Cpu size={14} className="text-cyber-cyan" /> Your response (analyzed by AI / rule-based engine)
            </label>
            <div className="flex gap-2">
              <textarea
                value={freeText}
                onChange={(e) => setFreeText(e.target.value)}
                rows={2}
                placeholder="Type how you would respond…"
                className="flex-1 rounded-lg border border-edge bg-bg-2 px-3 py-2 text-sm text-ink placeholder:text-ink-dim focus:border-cyber-cyan outline-none resize-none"
                disabled={busy || !sessionReady}
              />
              <button
                onClick={handleFreeText}
                disabled={busy || !freeText.trim() || !sessionReady}
                className="self-end rounded-lg bg-cyber-cyan text-bg-0 px-4 py-2 text-sm font-medium hover:bg-cyan-300 disabled:opacity-50 flex items-center gap-1.5"
              >
                <Send size={16} /> Send
              </button>
            </div>
          </div>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2">
            {choices.map((c) => (
              <button
                key={c.id}
                onClick={() => handleChoice(c)}
                disabled={busy || !sessionReady}
                className="group text-left rounded-lg border border-edge bg-bg-2 px-3 py-2.5 hover:border-cyber-cyan/50 hover:bg-surface-2 transition-colors disabled:opacity-50"
              >
                <div className="flex items-start gap-2">
                  <span className="font-mono-pro text-xs text-cyber-cyan mt-0.5">{c.code}</span>
                  <span className="text-sm text-ink">{c.choice_text}</span>
                </div>
              </button>
            ))}
            {choices.length === 0 && sessionReady && (
              <div className="col-span-2 text-center py-3 text-sm text-ink-muted">
                No choices available for this step.
              </div>
            )}
          </div>
        )}

        {!isEnd && sessionReady && (
          <div className="mt-2 text-[11px] text-ink-dim flex items-center gap-1">
            <CornerDownLeft size={12} /> Each choice changes the conversation and your risk score.
          </div>
        )}
      </div>
    </div>
  );
}

function ChatBubble({ message }: { message: ChatMessage }) {
  if (message.sender === 'student') {
    return (
      <div className="flex justify-end animate-fade-up">
        <div className="max-w-[85%] rounded-2xl rounded-br-sm bg-cyber-cyan/15 border border-cyber-cyan/30 px-3.5 py-2">
          <div className="flex items-center gap-1.5 text-[11px] text-cyber-cyan mb-1">
            <User size={12} /> You
          </div>
          <div className="text-sm text-ink">{message.text}</div>
          {message.explanation && (
            <div className="mt-2 rounded-lg bg-bg-2/70 border border-edge px-2.5 py-1.5 text-xs text-ink-muted">
              <span className="text-cyber-cyan font-medium">Why: </span>{message.explanation}
              {message.riskPoints !== undefined && (
                <span className={`ml-1 font-mono-pro ${message.riskPoints > 0 ? 'text-risk-high' : 'text-cyber-green'}`}>
                  ({message.riskPoints > 0 ? '+' : ''}{message.riskPoints} risk)
                </span>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  const isSystem = message.sender === 'system';
  return (
    <div className="flex justify-start animate-fade-up">
      <div
        className={`max-w-[85%] rounded-2xl rounded-bl-sm px-3.5 py-2 border ${
          isSystem
            ? 'bg-cyber-green/10 border-cyber-green/30'
            : 'bg-surface-2 border-edge-strong'
        }`}
      >
        <div className={`flex items-center gap-1.5 text-[11px] mb-1 ${isSystem ? 'text-cyber-green' : 'text-risk-high'}`}>
          {isSystem ? <ShieldAlert size={12} /> : <Bot size={12} />}
          {isSystem ? 'CyberShield System' : 'Simulated Scammer'}
        </div>
        <div className="text-sm text-ink whitespace-pre-wrap">{message.text}</div>
      </div>
    </div>
  );
}

function ErrorBox({ message }: { message: string }) {
  return (
    <div className="rounded-xl border border-risk-crit/40 bg-risk-crit/10 p-6 text-center">
      <AlertTriangle size={24} className="mx-auto text-risk-crit" />
      <p className="mt-2 text-sm text-risk-crit">{message}</p>
      <button onClick={() => navigateTo('/scenarios')} className="mt-4 rounded-lg border border-edge px-4 py-2 text-sm text-ink-muted hover:text-ink">
        Back to scenarios
      </button>
    </div>
  );
}
