import { navigateTo } from '@/lib/router';
import { Logo } from '@/components/Logo';
import { ShieldCheck, MessageSquareWarning, BrainCircuit, BarChart3, Lock, ArrowRight } from 'lucide-react';

export function LandingPage() {
  const features = [
    { icon: <MessageSquareWarning size={20} />, title: 'Branching scam scenarios', desc: '5+ realistic, fully fictional simulations. Every choice changes what happens next.' },
    { icon: <BrainCircuit size={20} />, title: 'AI response analysis', desc: 'Free-text answers are classified Safe → Extremely Risky with explainable feedback. Rule-based fallback always works.' },
    { icon: <BarChart3 size={20} />, title: 'Transparent risk scoring', desc: 'See exactly why each decision is safe or risky, with a normalized 0–100 cyber-risk score.' },
    { icon: <ShieldCheck size={20} />, title: 'Adaptive difficulty', desc: 'The system adjusts scenario difficulty based on your recent performance.' },
  ];

  return (
    <div className="cyber-bg min-h-screen flex flex-col">
      <header className="border-b border-edge/60">
        <div className="mx-auto max-w-6xl px-4 h-16 flex items-center justify-between">
          <Logo size={26} />
          <div className="flex items-center gap-2">
            <button onClick={() => navigateTo('/login')} className="text-sm text-ink-muted hover:text-ink px-3 py-1.5">Login</button>
            <button onClick={() => navigateTo('/register')} className="rounded-lg bg-cyber-cyan text-bg-0 px-4 py-1.5 text-sm font-medium hover:bg-cyan-300 transition-colors">Register</button>
          </div>
        </div>
      </header>

      <main className="flex-1 mx-auto w-full max-w-6xl px-4 py-12 sm:py-20">
        <div className="text-center max-w-3xl mx-auto animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-edge-strong bg-surface/60 px-3 py-1 text-xs text-cyber-cyan font-mono-pro">
            <Lock size={12} /> Educational · Fictional · No real credentials
          </span>
          <h1 className="mt-6 text-4xl sm:text-6xl font-bold tracking-tight text-ink">
            Test Your <span className="text-cyber-cyan">Cyber Awareness</span>
          </h1>
          <p className="mt-5 text-lg text-ink-muted">
            CyberShield places you in realistic, fully fictional scam conversations — fake job offers, UPI refund fraud, phishing emails, and more.
            Your decisions are scored, analyzed by AI, and turned into personalized recommendations so you learn to spot the red flags.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => navigateTo('/register')}
              className="group inline-flex items-center gap-2 rounded-lg bg-cyber-cyan text-bg-0 px-6 py-3 font-medium hover:bg-cyan-300 transition-colors shadow-glow"
            >
              Start Simulation
              <ArrowRight size={18} className="group-hover:translate-x-0.5 transition-transform" />
            </button>
            <button
              onClick={() => navigateTo('/login')}
              className="rounded-lg border border-edge-strong px-6 py-3 font-medium text-ink hover:bg-surface transition-colors"
            >
              Login
            </button>
          </div>
          <p className="mt-3 text-xs text-ink-dim">Free for academic use · BCS ASRP demonstration project</p>
        </div>

        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <div
              key={i}
              className="rounded-xl border border-edge bg-surface/70 p-5 hover:border-cyber-cyan/40 transition-colors animate-fade-up"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <div className="inline-flex items-center justify-center rounded-lg bg-cyber-cyan/10 text-cyber-cyan p-2.5">{f.icon}</div>
              <h3 className="mt-3 font-semibold text-ink">{f.title}</h3>
              <p className="mt-1 text-sm text-ink-muted">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 rounded-2xl border border-edge bg-surface/50 p-6 sm:p-8">
          <h2 className="text-xl font-semibold text-ink">How it works</h2>
          <ol className="mt-4 grid gap-4 sm:grid-cols-3">
            {[
              ['Choose a scenario', 'Pick from fake job offer, UPI refund, scholarship, phishing email, or account-recovery scam.'],
              ['Respond to the scammer', 'Each choice branches the conversation. Optional free-text answers are analyzed by AI.'],
              ['Get your report', 'Risk score, awareness score, key mistakes, and personalized recommendations — all explained.'],
            ].map(([t, d], i) => (
              <li key={i} className="rounded-lg border border-edge bg-bg-2 p-4">
                <div className="font-mono-pro text-cyber-cyan text-sm">0{i + 1}</div>
                <div className="mt-1 font-medium text-ink">{t}</div>
                <div className="mt-1 text-sm text-ink-muted">{d}</div>
              </li>
            ))}
          </ol>
        </div>
      </main>

      <footer className="border-t border-edge/60">
        <div className="mx-auto max-w-6xl px-4 py-6 text-xs text-ink-dim flex flex-col sm:flex-row justify-between gap-2">
          <span>CyberShield — all scenarios, identities, links, and financial details are fictional test data.</span>
          <span className="font-mono-pro">BCS ASRP</span>
        </div>
      </footer>
    </div>
  );
}
