import { useEffect, useState } from 'react';
import { useHashRoute, navigateTo } from '@/lib/router';
import { fetchSession, fetchScenario, fetchResponses, fetchRecommendations, fetchNodes } from '@/lib/data';
import type { Session, Scenario, ResponseRow, Recommendation, Node } from '@/lib/types';
import { RiskBadge } from '@/components/Risk';
import { CheckCircle2, XCircle, Cpu, FileText, ArrowLeft, Loader2 } from 'lucide-react';

export function ReportPage() {
  const [route] = useHashRoute();
  const sessionId = route.split('/')[2];

  const [session, setSession] = useState<Session | null>(null);
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [responses, setResponses] = useState<ResponseRow[]>([]);
  const [recs, setRecs] = useState<Recommendation[]>([]);
  const [nodes, setNodes] = useState<Record<string, Node>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!sessionId) return;
    (async () => {
      try {
        const s = await fetchSession(sessionId);
        if (!s) { setLoading(false); return; }
        setSession(s);
        const sc = await fetchScenario(s.scenario_id);
        setScenario(sc);
        const [rs, rc, ns] = await Promise.all([
          fetchResponses(sessionId),
          fetchRecommendations(sessionId),
          fetchNodes(s.scenario_id),
        ]);
        setResponses(rs);
        setRecs(rc);
        const map: Record<string, Node> = {};
        ns.forEach((n) => (map[n.id] = n));
        setNodes(map);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Failed to load report.');
      } finally {
        setLoading(false);
      }
    })();
  }, [sessionId]);

  if (loading) return <div className="py-20 text-center text-ink-muted flex items-center justify-center gap-2"><Loader2 size={18} className="animate-spin" /> Loading report…</div>;
  if (error) return <div className="py-20 text-center"><p className="text-sm text-risk-crit">{error}</p><button onClick={() => navigateTo('/history')} className="mt-4 rounded-lg border border-edge px-4 py-2 text-sm text-ink-muted hover:text-ink">Back to history</button></div>;
  if (!session) return <div className="py-20 text-center text-ink-muted">Session not found.</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <button onClick={() => navigateTo(`/result/${session.id}`)} className="rounded-lg border border-edge p-2 text-ink-muted hover:text-ink">
          <ArrowLeft size={18} />
        </button>
        <div>
          <div className="text-sm text-ink-muted">{scenario?.category}</div>
          <h1 className="text-2xl font-semibold text-ink">{scenario?.title ?? 'Scenario'} — Detailed Report</h1>
        </div>
      </div>

      {/* Summary bar */}
      <div className="rounded-xl border border-edge bg-surface p-5 grid gap-4 sm:grid-cols-4 text-center">
        <Metric label="Awareness" value={`${Math.round(session.awareness_score)}/100`} />
        <Metric label="Risk score" value={`${session.final_score}/100`} />
        <Metric label="Safe" value={session.safe_decisions} color="#34d399" />
        <Metric label="Risky" value={session.risky_decisions} color="#fb923c" />
      </div>

      {/* Decision-by-decision */}
      <div className="rounded-xl border border-edge bg-surface">
        <div className="border-b border-edge px-5 py-3 flex items-center gap-2">
          <FileText size={18} className="text-cyber-cyan" />
          <h3 className="font-semibold text-ink">Decision-by-decision breakdown</h3>
        </div>
        <ol className="divide-y divide-edge">
          {responses.map((r, i) => {
            const node = nodes[r.node_id];
            const isRisky = r.risk_points > 0;
            const ai = r.ai_analysis;
            return (
              <li key={r.id} className="px-5 py-4">
                <div className="flex items-start gap-3">
                  <span className="font-mono-pro text-xs text-ink-dim mt-1">{String(i + 1).padStart(2, '0')}</span>
                  <div className="flex-1 min-w-0">
                    {node && (
                      <div className="text-xs text-ink-dim mb-1.5 italic">
                        Scenario prompt: {node.message}
                      </div>
                    )}
                    <div className="flex items-center gap-2 mb-1.5">
                      {isRisky ? <XCircle size={16} className="text-risk-high shrink-0" /> : <CheckCircle2 size={16} className="text-cyber-green shrink-0" />}
                      <span className="text-sm font-medium text-ink">
                        {r.free_text ? 'Free-text response' : `Choice ${r.choice_code ?? ''}`}
                      </span>
                      <span className={`font-mono-pro text-xs ${isRisky ? 'text-risk-high' : 'text-cyber-green'}`}>
                        ({r.risk_points > 0 ? '+' : ''}{r.risk_points} risk)
                      </span>
                    </div>
                    <div className="rounded-lg bg-bg-2 border border-edge px-3 py-2 text-sm text-ink mb-2">
                      {r.free_text ? `"${r.free_text}"` : r.choice_code ? `Selected option ${r.choice_code}` : '—'}
                    </div>
                    <div className="text-sm text-ink-muted">
                      <span className={isRisky ? 'text-risk-high' : 'text-cyber-green'}>Why: </span>
                      {r.explanation}
                    </div>
                    {ai && (
                      <div className="mt-2 rounded-lg border border-cyber-cyan/25 bg-cyber-cyan/5 px-3 py-2 text-xs">
                        <div className="flex items-center gap-1.5 text-cyber-cyan mb-1">
                          <Cpu size={12} /> AI analysis ({ai.source})
                        </div>
                        <div className="text-ink-muted">
                          <span className="text-ink">Intent:</span> {ai.intent} · <span className="text-ink">Risk:</span> {ai.risk_level} · <span className="text-ink">Points:</span> {ai.risk_points}
                        </div>
                        <div className="text-ink-muted mt-1">{ai.explanation}</div>
                        {ai.matched_keywords.length > 0 && (
                          <div className="mt-1 text-ink-dim">Matched: {ai.matched_keywords.join(', ')}</div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
          {responses.length === 0 && (
            <li className="px-5 py-8 text-center text-sm text-ink-muted">No decisions recorded.</li>
          )}
        </ol>
      </div>

      {/* Recommendations */}
      <div className="rounded-xl border border-edge bg-surface">
        <div className="border-b border-edge px-5 py-3">
          <h3 className="font-semibold text-ink">Recommendations</h3>
        </div>
        <ul className="divide-y divide-edge">
          {recs.map((r) => (
            <li key={r.id} className="px-5 py-3 flex items-start gap-3">
              <span className={`mt-1 h-2 w-2 rounded-full shrink-0 ${r.priority === 'high' ? 'bg-risk-high' : r.priority === 'medium' ? 'bg-risk-med' : 'bg-cyber-green'}`} />
              <span className="text-sm text-ink">{r.recommendation}</span>
            </li>
          ))}
          {recs.length === 0 && <li className="px-5 py-4 text-sm text-ink-muted">None.</li>}
        </ul>
      </div>

      <div className="flex gap-3">
        <button onClick={() => navigateTo('/history')} className="rounded-lg border border-edge-strong px-4 py-2 text-sm text-ink hover:bg-surface">History</button>
        <button onClick={() => navigateTo('/scenarios')} className="rounded-lg bg-cyber-cyan text-bg-0 px-4 py-2 text-sm font-medium hover:bg-cyan-300">New scenario</button>
      </div>
    </div>
  );
}

function Metric({ label, value, color = '#e6f0f5' }: { label: string; value: string | number; color?: string }) {
  return (
    <div className="text-center">
      <div className="text-xs text-ink-dim uppercase tracking-wider">{label}</div>
      <div className="mt-1 font-mono-pro text-xl font-semibold" style={{ color }}>{value}</div>
    </div>
  );
}
