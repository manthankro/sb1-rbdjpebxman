import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth';
import { navigateTo } from '@/lib/router';
import {
  fetchAllProfiles,
  fetchAllSessions,
  fetchAllResponses,
  fetchAllScenarios,
  fetchScoringRules,
  updateScoringRule,
  updateScenario,
  deleteScenario,
  createScenario,
} from '@/lib/data';
import type { Session, ResponseRow, Scenario, ScoringRule, Difficulty } from '@/lib/types';
import { StatCard, BarChart } from '@/components/Charts';
import { Users, Activity, Award, TrendingDown, Plus, Trash2, Save, Loader2, ShieldAlert, AlertTriangle } from 'lucide-react';

type Tab = 'overview' | 'scenarios' | 'scoring' | 'students';

export function AdminPage() {
  const { profile } = useAuth();
  const [tab, setTab] = useState<Tab>('overview');

  const [profiles, setProfiles] = useState<{ id: string; full_name: string; role: string; created_at: string }[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [responses, setResponses] = useState<ResponseRow[]>([]);
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [rules, setRules] = useState<ScoringRule[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.role !== 'admin') { setLoading(false); return; }
    (async () => {
      try {
        const [p, s, r, sc, ru] = await Promise.all([
          fetchAllProfiles(),
          fetchAllSessions(),
          fetchAllResponses(),
          fetchAllScenarios(),
          fetchScoringRules(),
        ]);
        setProfiles(p);
        setSessions(s);
        setResponses(r);
        setScenarios(sc);
        setRules(ru);
      } catch (e) {
        console.warn('admin load', e);
      } finally {
        setLoading(false);
      }
    })();
  }, [profile]);

  if (loading) return <div className="py-20 text-center text-ink-muted flex items-center justify-center gap-2"><Loader2 size={18} className="animate-spin" /> Loading admin…</div>;

  if (profile?.role !== 'admin') {
    return (
      <div className="rounded-xl border border-risk-crit/40 bg-risk-crit/10 p-10 text-center">
        <ShieldAlert size={28} className="mx-auto text-risk-crit" />
        <p className="mt-2 text-sm text-risk-crit">Admin access required.</p>
        <button onClick={() => navigateTo('/dashboard')} className="mt-4 rounded-lg border border-edge px-4 py-2 text-sm text-ink-muted hover:text-ink">Back to dashboard</button>
      </div>
    );
  }

  const students = profiles.filter((p) => p.role === 'student');
  const completed = sessions.filter((s) => s.completed_at);
  const avgAwareness = completed.length ? completed.reduce((a, s) => a + s.awareness_score, 0) / completed.length : 0;

  // Most difficult scenario = lowest avg awareness with attempts.
  const scenarioStats: Record<string, { count: number; total: number }> = {};
  completed.forEach((s) => {
    const k = s.scenario_id;
    scenarioStats[k] = scenarioStats[k] ?? { count: 0, total: 0 };
    scenarioStats[k].count++;
    scenarioStats[k].total += s.awareness_score;
  });
  let hardest: { id: string; avg: number } | null = null as { id: string; avg: number } | null;
  Object.entries(scenarioStats).forEach(([id, v]) => {
    const avg = v.total / v.count;
    if (!hardest || avg < hardest.avg) hardest = { id, avg };
  });

  // Common mistakes: risky responses grouped by explanation keyword.
  const risky = responses.filter((r) => r.risk_points > 0);
  const mistakeCount: Record<string, number> = {};
  risky.forEach((r) => {
    const key = r.explanation.split('.')[0].slice(0, 60);
    mistakeCount[key] = (mistakeCount[key] ?? 0) + 1;
  });
  const topMistakes = Object.entries(mistakeCount).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const mistakeData = topMistakes.map(([label, value]) => ({ label: label.slice(0, 12) + '…', value }));

  const tabs: { id: Tab; label: string }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'scenarios', label: 'Scenarios' },
    { id: 'scoring', label: 'Scoring Rules' },
    { id: 'students', label: 'Students' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-ink">Admin dashboard</h1>
        <p className="text-sm text-ink-muted">Platform analytics and scenario management.</p>
      </div>

      <div className="flex gap-1 border-b border-edge">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 text-sm border-b-2 -mb-px transition-colors ${
              tab === t.id ? 'border-cyber-cyan text-cyber-cyan' : 'border-transparent text-ink-muted hover:text-ink'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Students" value={students.length} icon={<Users size={18} />} />
            <StatCard label="Simulations" value={completed.length} icon={<Activity size={18} />} />
            <StatCard label="Avg awareness" value={`${Math.round(avgAwareness)}`} icon={<Award size={18} />} accent="#34d399" />
            <StatCard label="Risky decisions" value={risky.length} icon={<TrendingDown size={18} />} accent="#fb923c" />
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="rounded-xl border border-edge bg-surface p-5">
              <h3 className="text-sm text-ink-muted mb-4">Most common mistakes</h3>
              {mistakeData.length ? <BarChart data={mistakeData} color="#fb923c" /> : <p className="text-sm text-ink-dim">No risky decisions logged yet.</p>}
            </div>
            <div className="rounded-xl border border-edge bg-surface p-5">
              <h3 className="text-sm text-ink-muted mb-4">Hardest scenario</h3>
              {hardest ? (
                <div>
                  <div className="font-semibold text-ink">{scenarios.find((s) => s.id === hardest!.id)?.title ?? 'Unknown'}</div>
                  <div className="mt-1 text-sm text-ink-muted">Avg awareness: <span className="font-mono-pro text-risk-high">{Math.round(hardest.avg)}/100</span></div>
                  <div className="mt-1 text-xs text-ink-dim">{scenarioStats[hardest.id].count} attempts</div>
                </div>
              ) : <p className="text-sm text-ink-dim">No attempts yet.</p>}
            </div>
          </div>

          <div className="rounded-xl border border-edge bg-surface">
            <div className="border-b border-edge px-5 py-3"><h3 className="font-semibold text-ink">Recent simulations</h3></div>
            <ul className="divide-y divide-edge">
              {completed.slice(0, 8).map((s) => {
                const sc = scenarios.find((x) => x.id === s.scenario_id);
                return (
                  <li key={s.id} className="px-5 py-3 flex items-center justify-between text-sm">
                    <span className="text-ink">{sc?.title ?? 'Scenario'}</span>
                    <span className="font-mono-pro text-ink-muted">{Math.round(s.awareness_score)}/100</span>
                  </li>
                );
              })}
              {completed.length === 0 && <li className="px-5 py-6 text-center text-ink-muted text-sm">No simulations yet.</li>}
            </ul>
          </div>
        </div>
      )}

      {tab === 'scenarios' && <ScenarioManager scenarios={scenarios} setScenarios={setScenarios} />}
      {tab === 'scoring' && <ScoringManager rules={rules} setRules={setRules} />}
      {tab === 'students' && (
        <div className="rounded-xl border border-edge bg-surface overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-surface-2 text-ink-dim text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3 font-medium">Name</th>
                <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">Joined</th>
                <th className="text-right px-4 py-3 font-medium">Simulations</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-edge">
              {students.map((p) => {
                const count = completed.filter((s) => s.user_id === p.id).length;
                return (
                  <tr key={p.id} className="hover:bg-surface-2/40">
                    <td className="px-4 py-3 text-ink">{p.full_name || '—'}</td>
                    <td className="px-4 py-3 text-ink-dim hidden sm:table-cell">{new Date(p.created_at).toLocaleDateString()}</td>
                    <td className="px-4 py-3 text-right font-mono-pro text-ink-muted">{count}</td>
                  </tr>
                );
              })}
              {students.length === 0 && <tr><td colSpan={3} className="px-4 py-8 text-center text-ink-muted">No students registered.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ScenarioManager({ scenarios, setScenarios }: { scenarios: Scenario[]; setScenarios: (s: Scenario[]) => void }) {
  const [showNew, setShowNew] = useState(false);
  const [form, setForm] = useState({ title: '', category: '', difficulty: 'easy' as Difficulty, description: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function create() {
    setBusy(true); setError(null);
    try {
      const s = await createScenario(form);
      setScenarios([...scenarios, s]);
      setForm({ title: '', category: '', difficulty: 'easy', description: '' });
      setShowNew(false);
    } catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
    finally { setBusy(false); }
  }

  async function toggle(s: Scenario) {
    try {
      await updateScenario(s.id, { active: !s.active });
      setScenarios(scenarios.map((x) => x.id === s.id ? { ...x, active: !x.active } : x));
    } catch (e) { console.warn(e); }
  }

  async function remove(s: Scenario) {
    if (!confirm(`Delete "${s.title}"? This removes its nodes and choices too.`)) return;
    try {
      await deleteScenario(s.id);
      setScenarios(scenarios.filter((x) => x.id !== s.id));
    } catch (e) { alert(e instanceof Error ? e.message : 'Failed'); }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button onClick={() => setShowNew(!showNew)} className="inline-flex items-center gap-2 rounded-lg bg-cyber-cyan text-bg-0 px-4 py-2 text-sm font-medium hover:bg-cyan-300">
          <Plus size={16} /> New scenario
        </button>
      </div>

      {showNew && (
        <div className="rounded-xl border border-cyber-cyan/30 bg-surface p-5 space-y-3">
          <h3 className="font-semibold text-ink">Add scenario (basic info)</h3>
          <p className="text-xs text-ink-dim">Note: nodes and choices for new scenarios are added via the database seed tool. This form creates the scenario record.</p>
          <div className="grid gap-3 sm:grid-cols-2">
            <input placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full rounded-lg border border-edge bg-bg-2 px-3 py-2 text-sm text-ink placeholder:text-ink-dim focus:border-cyber-cyan focus:outline-none" />
            <input placeholder="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full rounded-lg border border-edge bg-bg-2 px-3 py-2 text-sm text-ink placeholder:text-ink-dim focus:border-cyber-cyan focus:outline-none" />
            <select value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value as Difficulty })} className="w-full rounded-lg border border-edge bg-bg-2 px-3 py-2 text-sm text-ink focus:border-cyber-cyan focus:outline-none">
              <option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option>
            </select>
          </div>
          <textarea placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} className="w-full rounded-lg border border-edge bg-bg-2 px-3 py-2 text-sm text-ink placeholder:text-ink-dim focus:border-cyber-cyan focus:outline-none resize-none" />
          {error && <div className="text-xs text-risk-crit flex items-center gap-1"><AlertTriangle size={12} /> {error}</div>}
          <button onClick={create} disabled={busy || !form.title || !form.category} className="rounded-lg bg-cyber-green text-bg-0 px-4 py-2 text-sm font-medium hover:opacity-90 disabled:opacity-50">
            {busy ? <Loader2 size={16} className="animate-spin" /> : 'Create'}
          </button>
        </div>
      )}

      <div className="space-y-2">
        {scenarios.map((s) => (
          <div key={s.id} className="rounded-lg border border-edge bg-surface px-4 py-3 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="font-medium text-ink truncate">{s.title}</div>
              <div className="text-xs text-ink-dim">{s.category} · {s.difficulty} · {s.active ? 'Active' : 'Inactive'}</div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button onClick={() => toggle(s)} className={`text-xs rounded px-2 py-1 border ${s.active ? 'border-edge text-ink-muted' : 'border-cyber-green/40 text-cyber-green'}`}>
                {s.active ? 'Deactivate' : 'Activate'}
              </button>
              <button onClick={() => remove(s)} className="text-xs rounded border border-risk-crit/40 text-risk-crit px-2 py-1 hover:bg-risk-crit/10">
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ScoringManager({ rules, setRules }: { rules: ScoringRule[]; setRules: (r: ScoringRule[]) => void }) {
  const [editing, setEditing] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState<string | null>(null);

  async function save(rule: ScoringRule) {
    const val = parseInt(editing[rule.id], 10);
    if (isNaN(val)) return;
    setSaving(rule.id);
    try {
      await updateScoringRule(rule.id, val);
      setRules(rules.map((r) => r.id === rule.id ? { ...r, risk_points: val } : r));
      setEditing((e) => { const c = { ...e }; delete c[rule.id]; return c; });
    } catch (e) { alert(e instanceof Error ? e.message : 'Failed'); }
    finally { setSaving(null); }
  }

  return (
    <div className="rounded-xl border border-edge bg-surface">
      <div className="border-b border-edge px-5 py-3">
        <h3 className="font-semibold text-ink">Configurable scoring rules</h3>
        <p className="text-xs text-ink-dim mt-0.5">Positive values add risk; negative values reduce it (safe behaviors).</p>
      </div>
      <ul className="divide-y divide-edge">
        {rules.map((r) => (
          <li key={r.id} className="px-5 py-3 flex items-center justify-between gap-3">
            <div>
              <div className="text-sm text-ink">{r.label}</div>
              <div className="text-xs text-ink-dim font-mono-pro">{r.slug}</div>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={editing[r.id] ?? r.risk_points}
                onChange={(e) => setEditing({ ...editing, [r.id]: e.target.value })}
                className="w-20 rounded border border-edge bg-bg-2 px-2 py-1 text-sm text-ink text-center font-mono-pro focus:border-cyber-cyan outline-none"
              />
              <button
                onClick={() => save(r)}
                disabled={saving === r.id || !(r.id in editing)}
                className="rounded border border-edge px-2 py-1 text-xs text-ink-muted hover:text-cyber-cyan hover:border-cyber-cyan/40 disabled:opacity-40 flex items-center gap-1"
              >
                {saving === r.id ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />} Save
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
