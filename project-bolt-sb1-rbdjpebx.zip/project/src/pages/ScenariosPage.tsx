import { useEffect, useState } from 'react';
import { fetchScenarios } from '@/lib/data';
import type { Scenario, Difficulty } from '@/lib/types';
import { navigateTo } from '@/lib/router';
import { ShieldCheck, ArrowRight, Loader2 } from 'lucide-react';

const DIFF_STYLE: Record<Difficulty, { label: string; color: string; bg: string; border: string }> = {
  easy: { label: 'Easy', color: '#34d399', bg: 'rgba(52,211,153,0.10)', border: 'rgba(52,211,153,0.35)' },
  medium: { label: 'Medium', color: '#fbbf24', bg: 'rgba(251,191,36,0.10)', border: 'rgba(251,191,36,0.35)' },
  hard: { label: 'Hard', color: '#f87171', bg: 'rgba(248,113,113,0.10)', border: 'rgba(248,113,113,0.35)' },
};

export function ScenariosPage() {
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchScenarios()
      .then(setScenarios)
      .catch((e) => setError(e instanceof Error ? e.message : 'Failed to load scenarios.'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="py-20 text-center text-ink-muted flex items-center justify-center gap-2"><Loader2 size={18} className="animate-spin" /> Loading scenarios…</div>;
  }

  if (error) {
    return (
      <div className="rounded-xl border border-risk-crit/40 bg-risk-crit/10 p-8 text-center">
        <p className="text-sm text-risk-crit">{error}</p>
        <button onClick={() => window.location.reload()} className="mt-4 rounded-lg border border-edge px-4 py-2 text-sm text-ink-muted hover:text-ink">Try again</button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-ink">Choose a scenario</h1>
        <p className="text-sm text-ink-muted">All scenarios are fictional and for educational use. Each branches based on your choices.</p>
      </div>

      {scenarios.length === 0 ? (
        <div className="rounded-xl border border-edge bg-surface p-10 text-center text-ink-muted">
          No scenarios are available right now.
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {scenarios.map((s) => {
            const d = DIFF_STYLE[s.difficulty];
            return (
              <div key={s.id} className="group rounded-xl border border-edge bg-surface p-5 hover:border-cyber-cyan/40 transition-colors flex flex-col">
                <div className="flex items-start justify-between gap-3">
                  <div className="inline-flex items-center justify-center rounded-lg bg-cyber-cyan/10 text-cyber-cyan p-2.5">
                    <ShieldCheck size={20} />
                  </div>
                  <span
                    className="rounded-full border px-2.5 py-0.5 text-xs font-medium"
                    style={{ color: d.color, background: d.bg, borderColor: d.border }}
                  >
                    {d.label}
                  </span>
                </div>
                <h3 className="mt-3 font-semibold text-ink">{s.title}</h3>
                <div className="text-xs text-ink-dim mt-0.5">{s.category}</div>
                <p className="mt-2 text-sm text-ink-muted flex-1">{s.description}</p>
                <button
                  onClick={() => navigateTo(`/simulation/${s.id}`)}
                  className="mt-4 inline-flex items-center justify-center gap-2 rounded-lg border border-edge-strong px-4 py-2 text-sm font-medium text-ink hover:bg-cyber-cyan hover:text-bg-0 hover:border-cyber-cyan transition-colors group-hover:border-cyber-cyan/60"
                >
                  Start scenario <ArrowRight size={16} />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
