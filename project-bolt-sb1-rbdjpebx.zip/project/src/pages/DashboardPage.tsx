import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth';
import { navigateTo } from '@/lib/router';
import { fetchUserSessions, fetchScenario } from '@/lib/data';
import type { Session, Scenario } from '@/lib/types';
import { nextDifficulty } from '@/lib/adaptive';
import { RadialGauge, StatCard, LineChart, BarChart } from '@/components/Charts';
import { RiskBadge, levelFromScore } from '@/components/Risk';
import { ShieldCheck, Award, TrendingUp, Flame, ArrowRight, BookOpen, AlertTriangle } from 'lucide-react';

export function DashboardPage() {
  const { user, profile } = useAuth();
  const [sessions, setSessions] = useState<Session[]>([]);
  const [scenarios, setScenarios] = useState<Record<string, Scenario>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const s = await fetchUserSessions();
        const completed = s.filter((x) => x.completed_at);
        setSessions(completed);
        const map: Record<string, Scenario> = {};
        await Promise.all(
          [...new Set(completed.map((x) => x.scenario_id))].map(async (id) => {
            const sc = await fetchScenario(id);
            if (sc) map[id] = sc;
          })
        );
        setScenarios(map);
      } catch (e) {
        console.warn('dashboard load', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const completed = sessions;
  const avg = completed.length ? completed.reduce((s, x) => s + x.awareness_score, 0) / completed.length : 0;
  const last = completed[0];
  const recent = completed.slice(0, 6).reverse();
  const linePoints = recent.map((s, i) => ({ label: `#${i + 1}`, value: Math.round(s.awareness_score) }));

  // Adaptive recommendation based on recent performance.
  const adaptive = nextDifficulty(completed.slice(0, 3), last?.difficulty ?? 'easy');

  // Category breakdown.
  const byCat: Record<string, number> = {};
  completed.forEach((s) => {
    const cat = scenarios[s.scenario_id]?.category ?? 'Unknown';
    byCat[cat] = (byCat[cat] ?? 0) + 1;
  });
  const catData = Object.entries(byCat).map(([label, value]) => ({ label, value }));

  if (loading) {
    return <div className="py-20 text-center text-ink-muted">Loading your dashboard…</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-ink">Hello, {profile?.full_name || 'Student'}</h1>
          <p className="text-sm text-ink-muted">Your cyber-awareness training overview.</p>
        </div>
        <button
          onClick={() => navigateTo('/scenarios')}
          className="inline-flex items-center gap-2 rounded-lg bg-cyber-cyan text-bg-0 px-4 py-2 font-medium hover:bg-cyan-300 transition-colors self-start"
        >
          <ShieldCheck size={18} /> Start new simulation
        </button>
      </div>

      {/* Adaptive banner */}
      <div
        className={`rounded-xl border p-4 flex items-start gap-3 ${
          adaptive.shouldRecommendLearning
            ? 'border-risk-high/40 bg-risk-high/10 text-risk-high'
            : 'border-cyber-cyan/30 bg-cyber-cyan/5 text-cyber-cyan'
        }`}
      >
        {adaptive.shouldRecommendLearning ? <AlertTriangle size={20} className="mt-0.5 shrink-0" /> : <TrendingUp size={20} className="mt-0.5 shrink-0" />}
        <div className="text-sm">
          <div className="font-medium">Adaptive difficulty: next recommended level — {adaptive.nextDifficulty}</div>
          <div className="opacity-80">{adaptive.reason}</div>
          {adaptive.shouldRecommendLearning && (
            <div className="mt-1 opacity-90">Recommendation: review the "Cyber Basics" learning module before attempting harder scenarios.</div>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Awareness" value={`${Math.round(avg)}/100`} sub="Average score" icon={<Award size={18} />} accent="#34d399" />
        <StatCard label="Simulations" value={completed.length} sub="Completed" icon={<ShieldCheck size={18} />} />
        <StatCard label="Safe decisions" value={completed.reduce((s, x) => s + x.safe_decisions, 0)} sub="All time" icon={<TrendingUp size={18} />} accent="#34d399" />
        <StatCard label="Risky decisions" value={completed.reduce((s, x) => s + x.risky_decisions, 0)} sub="All time" icon={<Flame size={18} />} accent="#fb923c" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Gauge */}
        <div className="rounded-xl border border-edge bg-surface p-5 flex flex-col">
          <h3 className="text-sm text-ink-muted text-center">Current awareness</h3>
          <div className="mt-4 flex justify-center">
            <RadialGauge value={avg} label="Awareness" sublabel={completed.length ? `${completed.length} simulations` : 'No simulations yet'} color={avg >= 60 ? '#34d399' : avg >= 40 ? '#fbbf24' : '#f87171'} />
          </div>
          {last && (
            <div className="mt-3 flex justify-center">
              <RiskBadge level={levelFromScore(last.final_score)} score={last.final_score} size="sm" />
            </div>
          )}
        </div>

        {/* Progress line chart */}
        <div className="rounded-xl border border-edge bg-surface p-5 lg:col-span-2">
          <h3 className="text-sm text-ink-muted">Awareness over recent simulations</h3>
          <div className="mt-4">
            <LineChart points={linePoints.length ? linePoints : [{ label: '—', value: 0 }]} yMax={100} color="#34d399" />
          </div>
          {catData.length > 0 && (
            <>
              <h4 className="mt-6 text-xs text-ink-dim">By category</h4>
              <div className="mt-3">
                <BarChart data={catData} color="#22d3ee" />
              </div>
            </>
          )}
        </div>
      </div>

      {/* Recent simulations */}
      <div className="rounded-xl border border-edge bg-surface">
        <div className="flex items-center justify-between border-b border-edge px-5 py-3">
          <h3 className="font-semibold text-ink">Recent simulations</h3>
          <button onClick={() => navigateTo('/history')} className="text-sm text-cyber-cyan hover:underline flex items-center gap-1">
            View all <ArrowRight size={14} />
          </button>
        </div>
        {completed.length === 0 ? (
          <EmptyState />
        ) : (
          <ul className="divide-y divide-edge">
            {completed.slice(0, 5).map((s) => {
              const sc = scenarios[s.scenario_id];
              return (
                <li key={s.id} className="px-5 py-3 flex items-center justify-between gap-3 hover:bg-surface-2/50 transition-colors">
                  <div className="min-w-0">
                    <div className="font-medium text-ink truncate">{sc?.title ?? 'Scenario'}</div>
                    <div className="text-xs text-ink-dim">
                      {sc?.category} · {new Date(s.started_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="font-mono-pro text-sm text-ink">{Math.round(s.awareness_score)}</div>
                      <div className="text-[11px] text-ink-dim">awareness</div>
                    </div>
                    <RiskBadge level={s.result_level} size="sm" />
                    <button onClick={() => navigateTo(`/report/${s.id}`)} className="rounded-lg border border-edge px-2.5 py-1 text-xs text-ink-muted hover:text-cyber-cyan hover:border-cyber-cyan/40 transition-colors">
                      Report
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="px-5 py-10 text-center">
      <BookOpen size={32} className="mx-auto text-ink-dim" />
      <p className="mt-3 text-sm text-ink-muted">No simulations yet. Start your first scenario to see your progress here.</p>
      <button onClick={() => navigateTo('/scenarios')} className="mt-4 inline-flex items-center gap-2 rounded-lg bg-cyber-cyan text-bg-0 px-4 py-2 text-sm font-medium hover:bg-cyan-300">
        Browse scenarios <ArrowRight size={16} />
      </button>
    </div>
  );
}
