import { useEffect, useState } from 'react';
import { fetchUserSessions, fetchScenario } from '@/lib/data';
import { navigateTo } from '@/lib/router';
import type { Session, Scenario } from '@/lib/types';
import { RiskBadge } from '@/components/Risk';
import { History as HistoryIcon, Loader2, ArrowRight } from 'lucide-react';

export function HistoryPage() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [scenarios, setScenarios] = useState<Record<string, Scenario>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const s = await fetchUserSessions();
        const completed = s.filter((x) => x.completed_at);
        setSessions(completed);
        const map: Record<string, Scenario> = {};
        await Promise.all(
          [...new Set(completed.map((x) => x.scenario_id))].map(async (id) => {
            const sc = await fetchScenario(id);
            if (sc) map[id] = sc;
          })
        );
        setScenarios(map);
      } catch (e) {
        console.warn('history load', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <div className="py-20 text-center text-ink-muted flex items-center justify-center gap-2"><Loader2 size={18} className="animate-spin" /> Loading history…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <HistoryIcon size={24} className="text-cyber-cyan" />
        <div>
          <h1 className="text-2xl font-semibold text-ink">Simulation history</h1>
          <p className="text-sm text-ink-muted">All your completed scenarios.</p>
        </div>
      </div>

      {sessions.length === 0 ? (
        <div className="rounded-xl border border-edge bg-surface p-10 text-center">
          <p className="text-sm text-ink-muted">No simulations yet.</p>
          <button onClick={() => navigateTo('/scenarios')} className="mt-4 inline-flex items-center gap-2 rounded-lg bg-cyber-cyan text-bg-0 px-4 py-2 text-sm font-medium hover:bg-cyan-300">
            Start one <ArrowRight size={16} />
          </button>
        </div>
      ) : (
        <div className="rounded-xl border border-edge bg-surface overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-surface-2 text-ink-dim text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3 font-medium">Scenario</th>
                <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">Category</th>
                <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">Date</th>
                <th className="text-right px-4 py-3 font-medium">Awareness</th>
                <th className="text-left px-4 py-3 font-medium">Result</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-edge">
              {sessions.map((s) => {
                const sc = scenarios[s.scenario_id];
                return (
                  <tr key={s.id} className="hover:bg-surface-2/40">
                    <td className="px-4 py-3 text-ink font-medium">{sc?.title ?? 'Scenario'}</td>
                    <td className="px-4 py-3 text-ink-muted hidden sm:table-cell">{sc?.category ?? '—'}</td>
                    <td className="px-4 py-3 text-ink-dim hidden sm:table-cell">{new Date(s.started_at).toLocaleDateString()}</td>
                    <td className="px-4 py-3 text-right font-mono-pro text-ink">{Math.round(s.awareness_score)}</td>
                    <td className="px-4 py-3"><RiskBadge level={s.result_level} size="sm" /></td>
                    <td className="px-4 py-3 text-right">
                      <button onClick={() => navigateTo(`/report/${s.id}`)} className="text-xs text-cyber-cyan hover:underline">Report</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
