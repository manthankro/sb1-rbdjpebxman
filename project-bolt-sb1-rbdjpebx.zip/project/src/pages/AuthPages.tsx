import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { navigateTo } from '@/lib/router';
import { Logo } from '@/components/Logo';
import { Mail, Lock, AlertCircle, Loader2 } from 'lucide-react';

export function AuthPages({ mode }: { mode: 'login' | 'register' }) {
  const { signIn, signUp } = useAuth();
  const isRegister = mode === 'register';

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (isRegister && password !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setBusy(true);
    try {
      if (isRegister) {
        await signUp(name.trim() || email.split('@')[0], email.trim(), password);
      } else {
        await signIn(email.trim(), password);
      }
      navigateTo('/dashboard');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Authentication failed.';
      setError(msg);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="cyber-bg min-h-screen flex flex-col">
      <header className="border-b border-edge/60">
        <div className="mx-auto max-w-6xl px-4 h-16 flex items-center">
          <button onClick={() => navigateTo('/')}><Logo size={26} /></button>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md rounded-2xl border border-edge bg-surface/80 backdrop-blur p-6 sm:p-8 animate-fade-up">
          <h1 className="text-2xl font-semibold text-ink">{isRegister ? 'Create your account' : 'Welcome back'}</h1>
          <p className="mt-1 text-sm text-ink-muted">
            {isRegister ? 'Register to start practicing scam-awareness scenarios.' : 'Sign in to continue your training.'}
          </p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            {isRegister && (
              <Field label="Full name">
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Alex Student"
                  className="w-full rounded-lg border border-edge bg-bg-2 px-3 py-2.5 text-sm text-ink transition-colors placeholder:text-ink-dim focus:border-cyber-cyan focus:outline-none"
                  autoComplete="name"
                />
              </Field>
            )}
            <Field label="Email" icon={<Mail size={16} />}>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-lg border border-edge bg-bg-2 py-2.5 pl-9 pr-3 text-sm text-ink transition-colors placeholder:text-ink-dim focus:border-cyber-cyan focus:outline-none"
                autoComplete="email"
              />
            </Field>
            <Field label="Password" icon={<Lock size={16} />}>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-lg border border-edge bg-bg-2 py-2.5 pl-9 pr-3 text-sm text-ink transition-colors placeholder:text-ink-dim focus:border-cyber-cyan focus:outline-none"
                autoComplete={isRegister ? 'new-password' : 'current-password'}
              />
            </Field>
            {isRegister && (
              <Field label="Confirm password" icon={<Lock size={16} />}>
                <input
                  type="password"
                  required
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-lg border border-edge bg-bg-2 py-2.5 pl-9 pr-3 text-sm text-ink transition-colors placeholder:text-ink-dim focus:border-cyber-cyan focus:outline-none"
                  autoComplete="new-password"
                />
              </Field>
            )}

            {error && (
              <div className="flex items-start gap-2 rounded-lg border border-risk-crit/40 bg-risk-crit/10 px-3 py-2 text-sm text-risk-crit">
                <AlertCircle size={16} className="mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-cyber-cyan text-bg-0 px-4 py-2.5 font-medium hover:bg-cyan-300 transition-colors disabled:opacity-60"
            >
              {busy && <Loader2 size={16} className="animate-spin" />}
              {isRegister ? 'Create account' : 'Sign in'}
            </button>
          </form>

          <div className="mt-5 text-center text-sm text-ink-muted">
            {isRegister ? (
              <>Already have an account? <button onClick={() => navigateTo('/login')} className="text-cyber-cyan hover:underline">Login</button></>
            ) : (
              <>New here? <button onClick={() => navigateTo('/register')} className="text-cyber-cyan hover:underline">Register</button></>
            )}
          </div>
        </div>
      </main>

    </div>
  );
}

function Field({ label, icon, children }: { label: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs text-ink-muted mb-1.5">{label}</span>
      <div className="relative">
        {icon && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-dim">{icon}</span>}
        {children}
      </div>
    </label>
  );
}
