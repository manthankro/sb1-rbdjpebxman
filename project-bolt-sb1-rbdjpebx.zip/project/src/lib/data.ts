import { supabase } from './supabase';
import type {
  Scenario,
  Node,
  Choice,
  Session,
  ResponseRow,
  Recommendation,
  ScoringRule,
  NodeWithChoices,
} from './types';

// ---------------------------------------------------------------------------
// Data access helpers
// ---------------------------------------------------------------------------
// Thin wrappers around Supabase queries. Centralizing them keeps the
// components clean and makes the data flow easy to explain in the viva.

// --- Scenarios -------------------------------------------------------------

export async function fetchScenarios(): Promise<Scenario[]> {
  const { data, error } = await supabase
    .from('scenarios')
    .select('id, title, category, difficulty, description, starting_score, active, created_at')
    .eq('active', true)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data ?? []) as Scenario[];
}

export async function fetchAllScenarios(): Promise<Scenario[]> {
  const { data, error } = await supabase
    .from('scenarios')
    .select('id, title, category, difficulty, description, starting_score, active, created_at')
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data ?? []) as Scenario[];
}

export async function fetchScenario(id: string): Promise<Scenario | null> {
  const { data, error } = await supabase
    .from('scenarios')
    .select('id, title, category, difficulty, description, starting_score, active, created_at')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as Scenario | null;
}

// --- Nodes + choices -------------------------------------------------------

export async function fetchNodes(scenarioId: string): Promise<Node[]> {
  const { data, error } = await supabase
    .from('nodes')
    .select('id, scenario_id, code, message, sender, kind, is_start, is_end, next_node_id, created_at')
    .eq('scenario_id', scenarioId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data ?? []) as Node[];
}

export async function fetchChoices(scenarioId: string): Promise<Choice[]> {
  const { data, error } = await supabase
    .from('choices')
    .select('id, node_id, code, choice_text, risk_points, next_node_id, explanation, created_at')
    .in('node_id', (await fetchNodes(scenarioId)).map((n) => n.id));
  if (error) throw error;
  return (data ?? []) as Choice[];
}

export async function fetchScenarioGraph(scenarioId: string): Promise<{
  nodes: Node[];
  choices: Choice[];
  startNode: Node | null;
}> {
  const nodes = await fetchNodes(scenarioId);
  const nodeIds = nodes.map((n) => n.id);
  let choices: Choice[] = [];
  if (nodeIds.length) {
    const { data, error } = await supabase
      .from('choices')
      .select('id, node_id, code, choice_text, risk_points, next_node_id, explanation, created_at')
      .in('node_id', nodeIds)
      .order('code', { ascending: true });
    if (error) throw error;
    choices = (data ?? []) as Choice[];
  }
  const startNode = nodes.find((n) => n.is_start) ?? null;
  return { nodes, choices, startNode };
}

export function nodeWithChoices(node: Node, choices: Choice[]): NodeWithChoices {
  return { ...node, choices: choices.filter((c) => c.node_id === node.id) };
}

// --- Sessions + responses --------------------------------------------------

export async function createSession(
  scenarioId: string,
  difficulty: Session['difficulty']
): Promise<Session> {
  const { data, error } = await supabase
    .from('sessions')
    .insert({ scenario_id: scenarioId, difficulty })
    .select('id, user_id, scenario_id, difficulty, raw_score, final_score, awareness_score, result_level, safe_decisions, risky_decisions, started_at, completed_at')
    .maybeSingle();
  if (error) throw error;
  return data as Session;
}

export async function appendResponse(input: {
  session_id: string;
  node_id: string;
  choice_id: string | null;
  choice_code: string | null;
  free_text: string | null;
  risk_points: number;
  explanation: string;
  ai_analysis: ResponseRow['ai_analysis'];
}): Promise<ResponseRow> {
  const { data, error } = await supabase
    .from('responses')
    .insert(input)
    .select('id, session_id, user_id, node_id, choice_id, choice_code, free_text, risk_points, explanation, ai_analysis, created_at')
    .maybeSingle();
  if (error) throw error;
  return data as ResponseRow;
}

export async function completeSession(
  sessionId: string,
  summary: Pick<Session, 'raw_score' | 'final_score' | 'awareness_score' | 'result_level' | 'safe_decisions' | 'risky_decisions'>
): Promise<Session> {
  const { data, error } = await supabase
    .from('sessions')
    .update({ ...summary, completed_at: new Date().toISOString() })
    .eq('id', sessionId)
    .select('id, user_id, scenario_id, difficulty, raw_score, final_score, awareness_score, result_level, safe_decisions, risky_decisions, started_at, completed_at')
    .maybeSingle();
  if (error) throw error;
  return data as Session;
}

export async function insertRecommendations(
  sessionId: string,
  recs: Omit<Recommendation, 'id' | 'session_id' | 'created_at'>[]
): Promise<void> {
  if (recs.length === 0) return;
  const rows = recs.map((r) => ({ session_id: sessionId, recommendation: r.recommendation, priority: r.priority }));
  const { error } = await supabase.from('recommendations').insert(rows);
  if (error) throw error;
}

export async function fetchUserSessions(): Promise<Session[]> {
  const { data, error } = await supabase
    .from('sessions')
    .select('id, user_id, scenario_id, difficulty, raw_score, final_score, awareness_score, result_level, safe_decisions, risky_decisions, started_at, completed_at')
    .order('started_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as Session[];
}

export async function fetchSession(id: string): Promise<Session | null> {
  const { data, error } = await supabase
    .from('sessions')
    .select('id, user_id, scenario_id, difficulty, raw_score, final_score, awareness_score, result_level, safe_decisions, risky_decisions, started_at, completed_at')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as Session | null;
}

export async function fetchResponses(sessionId: string): Promise<ResponseRow[]> {
  const { data, error } = await supabase
    .from('responses')
    .select('id, session_id, user_id, node_id, choice_id, choice_code, free_text, risk_points, explanation, ai_analysis, created_at')
    .eq('session_id', sessionId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data ?? []) as ResponseRow[];
}

export async function fetchRecommendations(sessionId: string): Promise<Recommendation[]> {
  const { data, error } = await supabase
    .from('recommendations')
    .select('id, session_id, recommendation, priority, created_at')
    .eq('session_id', sessionId)
    .order('priority', { ascending: false });
  if (error) throw error;
  return (data ?? []) as Recommendation[];
}

// --- Scoring rules ---------------------------------------------------------

export async function fetchScoringRules(): Promise<ScoringRule[]> {
  const { data, error } = await supabase
    .from('scoring_rules')
    .select('id, slug, label, risk_points, updated_at')
    .order('risk_points', { ascending: false });
  if (error) throw error;
  return (data ?? []) as ScoringRule[];
}

export async function updateScoringRule(id: string, riskPoints: number): Promise<void> {
  const { error } = await supabase.from('scoring_rules').update({ risk_points: riskPoints }).eq('id', id);
  if (error) throw error;
}

// --- Admin analytics -------------------------------------------------------

export async function fetchAllProfiles(): Promise<{ id: string; full_name: string; role: string; created_at: string }[]> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, role, created_at')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as { id: string; full_name: string; role: string; created_at: string }[];
}

export async function fetchAllSessions(): Promise<Session[]> {
  const { data, error } = await supabase
    .from('sessions')
    .select('id, user_id, scenario_id, difficulty, raw_score, final_score, awareness_score, result_level, safe_decisions, risky_decisions, started_at, completed_at')
    .order('started_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as Session[];
}

export async function fetchAllResponses(): Promise<ResponseRow[]> {
  const { data, error } = await supabase
    .from('responses')
    .select('id, session_id, user_id, node_id, choice_id, choice_code, free_text, risk_points, explanation, ai_analysis, created_at');
  if (error) throw error;
  return (data ?? []) as ResponseRow[];
}

// --- Scenario admin CRUD ---------------------------------------------------

export async function createScenario(input: {
  title: string;
  category: string;
  difficulty: Session['difficulty'];
  description: string;
}): Promise<Scenario> {
  const { data, error } = await supabase
    .from('scenarios')
    .insert(input)
    .select('id, title, category, difficulty, description, starting_score, active, created_at')
    .maybeSingle();
  if (error) throw error;
  return data as Scenario;
}

export async function updateScenario(
  id: string,
  input: Partial<Pick<Scenario, 'title' | 'category' | 'difficulty' | 'description' | 'active'>>
): Promise<void> {
  const { error } = await supabase.from('scenarios').update(input).eq('id', id);
  if (error) throw error;
}

export async function deleteScenario(id: string): Promise<void> {
  const { error } = await supabase.from('scenarios').delete().eq('id', id);
  if (error) throw error;
}
