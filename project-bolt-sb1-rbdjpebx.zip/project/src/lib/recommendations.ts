import type { ResponseRow, Recommendation, ResultLevel } from './types';

// ---------------------------------------------------------------------------
// Recommendations engine
// ---------------------------------------------------------------------------
// Generates personalized, prioritized recommendations from the decisions a
// student made during a session. Rules are transparent and easy to explain.

export function generateRecommendations(
  resultLevel: ResultLevel,
  responses: { risk_points: number; explanation: string; free_text: string | null }[]
): Omit<Recommendation, 'id' | 'session_id' | 'created_at'>[] {
  const recs: Omit<Recommendation, 'id' | 'session_id' | 'created_at'>[] = [];
  const risky = responses.filter((r) => r.risk_points > 0);
  const safe = responses.filter((r) => r.risk_points <= 0);

  // 1. Level-based guidance.
  if (resultLevel === 'Critical Risk' || resultLevel === 'High Risk') {
    recs.push({
      recommendation:
        'Complete the "Cyber Basics" learning module before attempting harder scenarios. Focus on never sharing OTPs, passwords, or login codes.',
      priority: 'high',
    });
  } else if (resultLevel === 'Moderate Risk') {
    recs.push({
      recommendation:
        'Review the red flags you missed (urgent tone, upfront fees, mismatched links). Reattempt an easy scenario to reinforce safe habits.',
      priority: 'medium',
    });
  } else {
    recs.push({
      recommendation:
        'Strong awareness. Try a harder scenario or a different category to broaden your detection skills.',
      priority: 'low',
    });
  }

  // 2. Specific risky patterns.
  const sharedCreds = risky.some((r) =>
    /otp|password|login code|pin|cvv/i.test(r.free_text ?? r.explanation)
  );
  if (sharedCreds) {
    recs.push({
      recommendation:
        'Never share OTPs, passwords, PINs, or login codes. Legitimate organizations never ask for them over calls, SMS, or DM.',
      priority: 'high',
    });
  }

  const paidMoney = risky.some((r) => /pay|fee|send money|upi/i.test(r.free_text ?? r.explanation));
  if (paidMoney) {
    recs.push({
      recommendation:
        'Never pay upfront "registration", "refund", or "processing" fees to unsolicited contacts. Real employers, banks, and scholarships do not charge fees this way.',
      priority: 'high',
    });
  }

  const clickedLink = risky.some((r) => /click|link|verify-id\.fake|scholarfund\.fake/i.test(r.free_text ?? r.explanation));
  if (clickedLink) {
    recs.push({
      recommendation:
        'Hover over links and inspect sender addresses before clicking. When in doubt, go directly to the official app or website instead.',
      priority: 'medium',
    });
  }

  // 3. Positive reinforcement for consistent safe behavior.
  if (safe.length >= 3 && risky.length === 0) {
    recs.push({
      recommendation:
        'Excellent: you consistently verified through official sources and reported threats. Keep practicing and mentor peers on these habits.',
      priority: 'low',
    });
  }

  // 4. If no free-text responses were given, encourage articulation.
  const hasFreeText = responses.some((r) => r.free_text && r.free_text.trim().length > 0);
  if (!hasFreeText) {
    recs.push({
      recommendation:
        'Try the free-text responses too — articulating your reasoning in your own words deepens retention and is analyzed for safety.',
      priority: 'low',
    });
  }

  // De-duplicate identical recommendations.
  const seen = new Set<string>();
  return recs.filter((r) => {
    if (seen.has(r.recommendation)) return false;
    seen.add(r.recommendation);
    return true;
  });
}
