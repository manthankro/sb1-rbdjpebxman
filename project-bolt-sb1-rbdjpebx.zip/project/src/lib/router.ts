import { useEffect, useState } from 'react';

// Minimal hash-based router. No extra dependency — keeps the project lean and
// easy to explain. Routes look like #/dashboard, #/simulation/:scenarioId, etc.

export function useHashRoute(): [string, (to: string) => void] {
  const [route, setRoute] = useState(() => window.location.hash.replace(/^#/, '') || '/');

  useEffect(() => {
    const onChange = () => setRoute(window.location.hash.replace(/^#/, '') || '/');
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);

  const navigate = (to: string) => {
    window.location.hash = to;
  };

  return [route, navigate];
}

export function navigateTo(to: string) {
  window.location.hash = to;
}
