import type { ResultLevel } from './types';

// ---------------------------------------------------------------------------
// Scoring engine
// ---------------------------------------------------------------------------
// CyberShield uses a transparent, additive risk model. Each decision adds or
// subtracts risk points (configured per-choice in the database). The raw total
// is normalized to a 0-100 "risk score"; the "awareness score" is its inverse.
//
// Risk levels:
//   0-20   Excellent
//   21-40  Good
//   41-60  Moderate Risk
//   61-80  High Risk
//   81-100 Critical Risk
//
// A decision counts as "safe" if its risk_points are <= 0, "risky" otherwise.

export interface ScoreBreakdown {
  raw_score: number;
  final_score: number;
  awareness_score: number;
  result_level: ResultLevel;
  safe_decisions: number;
  risky_decisions: number;
}

export function levelForRisk(score: number): ResultLevel {
  if (score <= 20) return 'Excellent';
  if (score <= 40) return 'Good';
  if (score <= 60) return 'Moderate Risk';
  if (score <= 80) return 'High Risk';
  return 'Critical Risk';
}

// Normalize a raw (possibly negative) total into a 0-100 risk score.
// We clamp at 0 and 100. Negative raw scores (very safe play) map to ~0 risk.
export function normalizeRisk(raw: number): number {
  const clamped = Math.max(0, Math.min(100, raw));
  return Math.round(clamped);
}

export function computeScore(riskPoints: number[]): ScoreBreakdown {
  const raw_score = riskPoints.reduce((sum, p) => sum + p, 0);
  const final_score = normalizeRisk(raw_score);
  const awareness_score = 100 - final_score;
  const safe_decisions = riskPoints.filter((p) => p <= 0).length;
  const risky_decisions = riskPoints.filter((p) => p > 0).length;

  return {
    raw_score,
    final_score,
    awareness_score,
    result_level: levelForRisk(final_score),
    safe_decisions,
    risky_decisions,
  };
}
