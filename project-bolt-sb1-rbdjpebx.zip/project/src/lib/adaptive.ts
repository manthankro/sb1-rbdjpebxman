import type { Difficulty, Session } from './types';

// ---------------------------------------------------------------------------
// Adaptive difficulty
// ---------------------------------------------------------------------------
// Picks a recommended difficulty for the student's NEXT scenario based on
// their recent performance. The rule is simple and explainable:
//
//   - Look at the last few completed sessions.
//   - If the student consistently scores well (awareness >= 70), step up.
//   - If they consistently score poorly (awareness < 40), step down and
//     recommend a learning module first.
//   - Otherwise stay at the same level.
//
// Difficulty only moves one step at a time so progress is gradual.

const ORDER: Record<Difficulty, number> = { easy: 0, medium: 1, hard: 2 };
const NUMBERS: Record<number, Difficulty> = { 0: 'easy', 1: 'medium', 2: 'hard' };

export interface AdaptiveResult {
  nextDifficulty: Difficulty;
  shouldRecommendLearning: boolean;
  reason: string;
}

export function nextDifficulty(recent: Session[], current: Difficulty): AdaptiveResult {
  if (recent.length === 0) {
    return {
      nextDifficulty: current,
      shouldRecommendLearning: false,
      reason: 'No previous attempts yet. Starting at the selected difficulty.',
    };
  }

  const last = recent.slice(0, 3);
  const avgAwareness = last.reduce((s, x) => s + x.awareness_score, 0) / last.length;

  if (avgAwareness >= 70) {
    const stepped = Math.min(2, ORDER[current] + 1);
    return {
      nextDifficulty: NUMBERS[stepped],
      shouldRecommendLearning: false,
      reason: `Average awareness ${avgAwareness.toFixed(0)}/100 over recent attempts — stepping up to ${NUMBERS[stepped]}.`,
    };
  }

  if (avgAwareness < 40) {
    const stepped = Math.max(0, ORDER[current] - 1);
    return {
      nextDifficulty: NUMBERS[stepped],
      shouldRecommendLearning: true,
      reason: `Average awareness ${avgAwareness.toFixed(0)}/100 is low — easing to ${NUMBERS[stepped]} and recommending a learning module first.`,
    };
  }

  return {
    nextDifficulty: current,
    shouldRecommendLearning: false,
    reason: `Average awareness ${avgAwareness.toFixed(0)}/100 — staying at ${current}.`,
  };
}
