// Shared TypeScript types that mirror the database tables.
// Keeping them in one place makes the data flow easy to follow during the viva.

export type Role = 'student' | 'admin';
export type Difficulty = 'easy' | 'medium' | 'hard';
export type NodeKind = 'scammer' | 'choice' | 'free_text' | 'end';
export type Sender = 'scammer' | 'student' | 'system';
export type ResultLevel = 'Excellent' | 'Good' | 'Moderate Risk' | 'High Risk' | 'Critical Risk';
export type RecommendationPriority = 'low' | 'medium' | 'high';

export interface Profile {
  id: string;
  full_name: string;
  role: Role;
  created_at: string;
}

export interface Scenario {
  id: string;
  title: string;
  category: string;
  difficulty: Difficulty;
  description: string;
  starting_score: number;
  active: boolean;
  created_at: string;
}

export interface Node {
  id: string;
  scenario_id: string;
  code: string;
  message: string;
  sender: Sender;
  kind: NodeKind;
  is_start: boolean;
  is_end: boolean;
  next_node_id: string | null;
  created_at: string;
}

export interface Choice {
  id: string;
  node_id: string;
  code: string;
  choice_text: string;
  risk_points: number;
  next_node_id: string | null;
  explanation: string;
  created_at: string;
}

export interface Session {
  id: string;
  user_id: string;
  scenario_id: string;
  difficulty: Difficulty;
  raw_score: number;
  final_score: number;
  awareness_score: number;
  result_level: ResultLevel;
  safe_decisions: number;
  risky_decisions: number;
  started_at: string;
  completed_at: string | null;
}

export interface ResponseRow {
  id: string;
  session_id: string;
  user_id: string;
  node_id: string;
  choice_id: string | null;
  choice_code: string | null;
  free_text: string | null;
  risk_points: number;
  explanation: string;
  ai_analysis: AiAnalysis | null;
  created_at: string;
}

export interface Recommendation {
  id: string;
  session_id: string;
  recommendation: string;
  priority: RecommendationPriority;
  created_at: string;
}

export interface ScoringRule {
  id: string;
  slug: string;
  label: string;
  risk_points: number;
  updated_at: string;
}

// AI analysis shape (stored as jsonb on responses.ai_analysis).
export interface AiAnalysis {
  intent: 'Safe' | 'Suspicious' | 'Risky' | 'Extremely Risky' | 'Verification' | 'Reporting';
  risk_level: 'Low' | 'Medium' | 'High' | 'Critical';
  risk_points: number;
  explanation: string;
  matched_keywords: string[];
  source: 'rule-based' | 'ai-api';
}

// A node joined with its choices, as the simulator consumes it.
export interface NodeWithChoices extends Node {
  choices: Choice[];
}
