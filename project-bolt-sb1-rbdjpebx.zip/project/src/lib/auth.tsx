import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Session as SupaSession, User } from '@supabase/supabase-js';
import { supabase } from './supabase';
import type { Profile } from './types';

// ---------------------------------------------------------------------------
// Auth context
// ---------------------------------------------------------------------------
// Wraps Supabase email/password auth and exposes the current user + profile.
// After every sign-in / sign-up we fetch or create the matching profile row
// (with role = 'student' by default). Admin role is granted manually via the
// DB for demonstration accounts.

interface AuthState {
  user: User | null;
  profile: Profile | null;
  session: SupaSession | null;
  loading: boolean;
  signUp: (name: string, email: string, password: string) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthState | undefined>(undefined);

async function fetchProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, role, created_at')
    .eq('id', userId)
    .maybeSingle();
  if (error) {
    console.warn('fetchProfile error', error.message);
    return null;
  }
  return data as Profile | null;
}

async function ensureProfile(user: User, name: string): Promise<Profile | null> {
  const existing = await fetchProfile(user.id);
  if (existing) return existing;
  const { data, error } = await supabase
    .from('profiles')
    .insert({ id: user.id, full_name: name, role: 'student' })
    .select('id, full_name, role, created_at')
    .maybeSingle();
  if (error) {
    console.warn('ensureProfile insert error', error.message);
    return null;
  }
  return data as Profile | null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [session, setSession] = useState<SupaSession | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initial session load.
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setUser(data.session?.user ?? null);
      if (data.session?.user) {
        fetchProfile(data.session.user.id).then((p) => {
          setProfile(p);
          setLoading(false);
        });
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes. Wrap async work in an IIFE to avoid the
    // onAuthStateChange deadlock documented in the Supabase guidance.
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => {
      (async () => {
        setSession(sess);
        setUser(sess?.user ?? null);
        if (sess?.user) {
          let p = await fetchProfile(sess.user.id);
          if (!p) {
            p = await ensureProfile(sess.user, sess.user.email?.split('@')[0] ?? 'Student');
          }
          setProfile(p);
        } else {
          setProfile(null);
        }
        setLoading(false);
      })();
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  const value = useMemo<AuthState>(
    () => ({
      user,
      profile,
      session,
      loading,
      async signUp(name, email, password) {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        if (data.user) {
          const p = await ensureProfile(data.user, name);
          if (p) setProfile(p);
        }
      },
      async signIn(email, password) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      },
      async signOut() {
        await supabase.auth.signOut();
        setUser(null);
        setProfile(null);
        setSession(null);
      },
    }),
    [user, profile, session, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
