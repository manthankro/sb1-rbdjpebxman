import type { AiAnalysis } from './types';

// ---------------------------------------------------------------------------
// AI / NLP response analyzer
// ---------------------------------------------------------------------------
// CyberShield analyzes the student's free-text responses to scam scenarios.
//
// IMPORTANT: This module NEVER generates scam or phishing instructions. It only
// CLASSIFIES a student's already-written response and returns educational
// feedback. The student is the author; we only judge safety.
//
// Two modes:
//   1. Rule-based fallback (default, always available): keyword + pattern match.
//   2. External AI API (optional): if an API key were configured in an edge
//      function, that service could replace this local logic. The interface
//      (AiAnalysis) stays the same so the rest of the app is unchanged.
//
// The rule-based classifier is intentionally transparent so a BCS student can
// explain every decision during the viva.

type Intent = AiAnalysis['intent'];
type RiskLevel = AiAnalysis['risk_level'];

// Keyword banks. Each maps an intent + risk. Words are matched case-insensitive
// as whole-word substrings. The first matching bucket wins, checked in priority
// order: highest-risk behaviors first so that e.g. "I'll share my OTP" is not
// misclassified as safe because it also contains "verify".
interface Bucket {
  intent: Intent;
  risk_level: RiskLevel;
  risk_points: number;
  keywords: string[];
  explanation: string;
}

const BUCKETS: Bucket[] = [
  {
    intent: 'Extremely Risky',
    risk_level: 'Critical',
    risk_points: 40,
    keywords: ['password', 'otp', 'login code', 'pin', 'cvv', 'share my', "here's my", 'here is my', 'sent the', 'sending you'],
    explanation: 'The response indicates willingness to share credentials or authentication codes. These should never be shared with anyone.',
  },
  {
    intent: 'Risky',
    risk_level: 'High',
    risk_points: 30,
    keywords: ['pay', 'fee', 'send money', 'bank details', 'account number', 'upi id', 'click the link', 'click link', 'fill in', 'fill out', 'register', 'forward it', 'forward this'],
    explanation: 'The response suggests paying a fee, sharing financial details, clicking a suspicious link, or forwarding an unverified message — all high-risk actions.',
  },
  {
    intent: 'Suspicious',
    risk_level: 'Medium',
    risk_points: 15,
    keywords: ['maybe', 'i guess', 'not sure', 'might be', 'could be real', 'just in case', 'sounds good', 'okay sure', 'ok sure', 'sure, i'],
    explanation: 'The response shows uncertainty or a tendency to comply despite doubts. Scammers exploit hesitation — verify independently before acting.',
  },
  {
    intent: 'Reporting',
    risk_level: 'Low',
    risk_points: -20,
    keywords: ['report', 'spam', 'block', 'fraud', 'scam', 'police', 'cyber', '1930', 'complaint'],
    explanation: 'The response focuses on reporting and blocking — strong protective behavior that also helps protect the community.',
  },
  {
    intent: 'Verification',
    risk_level: 'Low',
    risk_points: -10,
    keywords: ['verify', 'official', 'check the website', 'check the app', 'confirm', 'contact the bank', 'help center', 'verify-id', 'not share', "won't share", 'will not share', 'refuse', 'hang up', 'delete'],
    explanation: 'The response chooses independent verification or refusal — exactly the right instincts when facing a suspected scam.',
  },
  {
    intent: 'Safe',
    risk_level: 'Low',
    risk_points: -15,
    keywords: ['no', 'never', 'do not', 'don\'t', 'ignore', 'suspicious', 'red flag', 'phishing', 'fake'],
    explanation: 'The response recognizes the danger and declines to engage. Good cyber-awareness behavior.',
  },
];

const PRIORITY_ORDER: Intent[] = [
  'Extremely Risky',
  'Risky',
  'Suspicious',
  'Reporting',
  'Verification',
  'Safe',
];

function matchKeywords(text: string, keywords: string[]): string[] {
  const lower = text.toLowerCase();
  return keywords.filter((k) => lower.includes(k));
}

// Main entry point. Returns an AiAnalysis using the rule-based fallback.
export function analyzeResponse(text: string): AiAnalysis {
  const trimmed = text.trim();
  if (!trimmed) {
    return {
      intent: 'Suspicious',
      risk_level: 'Medium',
      risk_points: 10,
      explanation: 'No response was provided. In a real situation, staying silent does not protect you — actively verify and refuse.',
      matched_keywords: [],
      source: 'rule-based',
    };
  }

  for (const intent of PRIORITY_ORDER) {
    const bucket = BUCKETS.find((b) => b.intent === intent);
    if (!bucket) continue;
    const matched = matchKeywords(trimmed, bucket.keywords);
    if (matched.length > 0) {
      return {
        intent: bucket.intent,
        risk_level: bucket.risk_level,
        risk_points: bucket.risk_points,
        explanation: bucket.explanation,
        matched_keywords: matched,
        source: 'rule-based',
      };
    }
  }

  // No keyword matched — treat as neutral/uncertain.
  return {
    intent: 'Suspicious',
    risk_level: 'Medium',
    risk_points: 5,
    explanation:
      'The response did not clearly state a safe or risky action. A clear plan (verify via official channels, refuse to share credentials, report) is safer than ambiguity.',
    matched_keywords: [],
    source: 'rule-based',
  };
}
