import { createClient } from '@supabase/supabase-js';

// Supabase client (singleton). Credentials come from the pre-populated .env.
// The anon key is safe to expose in frontend code — it only allows actions
// permitted by Row Level Security policies defined on each table.
const url = import.meta.env.VITE_SUPABASE_URL as string;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!url || !anonKey) {
  throw new Error('Missing Supabase env vars. Check VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY in .env');
}

export const supabase = createClient(url, anonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});
