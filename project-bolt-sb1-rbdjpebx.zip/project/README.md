# CyberShield — AI-Based Adaptive Scam Conversation Simulator

An educational cybersecurity awareness platform for a BCS Academic Student Research
Project (ASRP). Students practice identifying scams in realistic **fictional**
conversation simulations, receive transparent risk scoring, AI-based analysis of
free-text responses, and personalized recommendations. Performance is tracked over
time with adaptive difficulty.

> All scenarios, identities, links, phone numbers, and financial details are
> **fictional test data**. The application never performs real scams, sends real
> phishing messages, collects real credentials, or interacts with real victims.
> The AI component only **classifies student responses** — it never generates
> scam or phishing instructions.

---

## Tech stack

This project was specified as Flask/SQLite but is implemented on a modern,
reliable equivalent stack suited to this environment:

| Layer | Technology |
|------|-------------|
| Frontend | React + TypeScript + Vite |
| Styling | Tailwind CSS (dark cyber theme, neon cyan/green) |
| Backend / Database | Supabase (PostgreSQL + Auth + Row Level Security) |
| Charts | Custom lightweight SVG components (no extra dependency) |
| AI/NLP | Rule-based keyword classifier with a pluggable interface for an external API |
| Icons | lucide-react |

The architecture mirrors the original spec: scenario/conversation-node/choice data
model, scoring engine, AI analyzer, recommendations, adaptive difficulty, student
dashboard, admin dashboard, and reports.

---

## Features

### Student
- Register / login / logout (email + password, securely hashed by Supabase Auth)
- Dashboard: current awareness score, simulations completed, average score, recent
  simulations, progress chart, adaptive difficulty recommendation
- Scenario selection with category, difficulty, and description cards
- Interactive messaging-style scam conversation simulator with branching choices
- Free-text responses analyzed by the AI/rule-based engine
- Transparent risk scoring with a live risk meter during the simulation
- Result page: final score, awareness score, risk category, safe/risky counts,
  personalized recommendations
- Detailed decision-by-decision report explaining why each choice was safe or risky
- Simulation history table
- Progress charts (line + bar)

### Admin
- Admin dashboard with total students, total simulations, average awareness,
  hardest scenario, most common mistakes, charts
- Scenario management (create, activate/deactivate, delete)
- Configurable scoring rules (edit risk points live)
- Student list

---

## Scam scenarios (5, all fictional)

1. **Fake Job Offer** (easy) — employment scam with upfront "registration fee"
2. **Fake UPI / Payment Refund** (medium) — OTP-based payment fraud
3. **Fake Scholarship** (medium) — phishing SMS with a fake claim link
4. **Phishing Email** (easy) — urgent "account suspension" email
5. **Social-Media Account Recovery Scam** (hard) — impostor "support" account

Each scenario is a branching decision tree: every choice leads to a different
follow-up message and has an associated risk value and explanation.

---

## Risk scoring

Transparent and configurable. Each decision adds or subtracts risk points
(stored per choice in the database, editable by the admin):

| Action | Risk points |
|--------|-------------|
| Share OTP / auth code | +30 |
| Share password | +40 |
| Send money / pay a fee | +35 |
| Share sensitive personal info | +30 |
| Click a suspicious link | +25 |
| Ignore warning signs | +10 |
| Ask for verification | -10 |
| Refuse to pay | -15 |
| Verify via official source | -20 |
| Report the scam | -20 |

The raw total is normalized to a **0–100 risk score**. **Awareness = 100 − risk.**

Risk levels: 0–20 Excellent · 21–40 Good · 41–60 Moderate · 61–80 High · 81–100 Critical

---

## AI / NLP component

`src/lib/analyzer.ts` classifies free-text student responses into:

Safe · Suspicious · Risky · Extremely Risky · Verification · Reporting

It returns an intent, risk level, risk points, an explanation, and matched
keywords. The interface (`AiAnalysis`) is designed so an external AI API
(deployed as a Supabase Edge Function) could replace the local logic without
changing the rest of the app. If no API key is configured, the **rule-based
fallback** always works.

The AI **only analyzes** student-authored text. It never generates scam
instructions or phishing content.

---

## Adaptive difficulty

`src/lib/adaptive.ts` looks at the student's last few completed sessions:
- Average awareness ≥ 70 → step up (easy → medium → hard)
- Average awareness < 40 → step down and recommend a learning module first
- Otherwise stay at the same level

Difficulty moves one step at a time so progress is gradual.

---

## Project structure

```
src/
  lib/
    supabase.ts        # Supabase client (singleton)
    types.ts           # Shared TypeScript types (mirror DB tables)
    auth.tsx           # Auth context (sign up / in / out, profile)
    data.ts            # Data-access helpers (scenarios, sessions, admin)
    scoring.ts         # Risk scoring engine (normalize, levels)
    analyzer.ts        # AI / rule-based free-text analyzer
    recommendations.ts# Personalized recommendation generator
    adaptive.ts        # Adaptive difficulty logic
    router.ts          # Minimal hash-based router
  components/
    Layout.tsx         # App shell + nav
    Logo.tsx           # CyberShield logo
    Risk.tsx           # Risk badges + bars
    Charts.tsx         # SVG gauge / bar / line charts
  pages/
    LandingPage.tsx
    AuthPages.tsx      # Login + Register
    DashboardPage.tsx
    ScenariosPage.tsx
    SimulationPage.tsx # Branching conversation engine
    ResultPage.tsx
    ReportPage.tsx
    HistoryPage.tsx
    AdminPage.tsx
  App.tsx              # Router + auth gating
  main.tsx             # Entry, wraps App in AuthProvider
supabase/migrations/   # Schema + seed SQL (applied via Supabase MCP)
```

---

## Running

The dev server runs automatically in this environment. For local development:

```bash
npm install
npm run dev      # start Vite dev server
npm run build    # production build
npm run typecheck# TypeScript check
```

Environment variables (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`) are
pre-populated in `.env`.

---

## Database

Schema and seed data are applied via Supabase migrations (SQL in
`supabase/migrations/`). Tables:

- `profiles` — display name + role (student/admin), linked to Supabase Auth
- `scenarios` — fictional scam scenarios
- `nodes` — conversation tree nodes (scammer / student / system / free-text / end)
- `choices` — selectable responses with risk_points, next_node_id, explanation
- `sessions` — a student's attempt (scores, result level, difficulty)
- `responses` — each decision (choice or free-text + AI analysis)
- `recommendations` — personalized feedback per session
- `scoring_rules` — configurable risk point values

Row Level Security is enabled on every table. Students can only access their own
sessions and responses; admins get read access to all data plus write access to
scenarios and scoring rules.

---

## Demo accounts

1. Register a new student account from the Register page.
2. To demo the admin dashboard, set a profile's role to `admin` in the database:
   ```sql
   UPDATE profiles SET role = 'admin' WHERE id = '<your-user-id>';
   ```
   Then sign out and back in.

---

## ASRP viva — quick talking points

- **Goal**: teach scam awareness through safe, fictional practice.
- **Scoring**: transparent, additive, normalized 0–100; awareness is the inverse.
- **AI**: classifies free-text responses with explainable rules; pluggable for an
  external API; never generates scam content.
- **Adaptive**: difficulty adjusts to recent performance.
- **Security**: Supabase Auth (hashed passwords), Row Level Security, input
  validation, no real credentials stored, all data fictional.
- **Measurable**: awareness score, risk level, safe/risky decision counts,
  per-decision explanations, history, admin analytics.
