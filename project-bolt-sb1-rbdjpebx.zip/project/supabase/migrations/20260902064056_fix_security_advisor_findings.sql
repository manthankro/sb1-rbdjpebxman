-- Fix security advisor findings:
-- 1. scenario_stats view should not be SECURITY DEFINER (it should run as the
--    querying user so RLS applies). Recreate as SECURITY INVOKER.
-- 2. set_updated_at function needs an explicit search_path to prevent
--    search-path injection.

CREATE OR REPLACE VIEW scenario_stats WITH (security_invoker = true) AS
SELECT
  s.id AS scenario_id,
  s.title,
  s.category,
  s.difficulty,
  COUNT(sess.id) AS attempt_count,
  COALESCE(ROUND(AVG(sess.awareness_score), 1), 0) AS avg_awareness,
  COALESCE(ROUND(AVG(sess.final_score), 1), 0) AS avg_risk
FROM scenarios s
LEFT JOIN sessions sess ON sess.scenario_id = s.id
GROUP BY s.id, s.title, s.category, s.difficulty;

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;
