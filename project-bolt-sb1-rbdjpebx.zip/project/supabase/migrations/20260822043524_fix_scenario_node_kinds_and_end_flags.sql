-- Fix node kind/sender mismatches and is_end flags that broke simulation flow.

-- Scenario 3 (Fake Scholarship): B1 is a system guidance node with choices, not a scammer node.
UPDATE nodes SET kind = 'choice'
WHERE code = 'B1' AND scenario_id = (
  SELECT id FROM scenarios WHERE title = 'Fake Scholarship'
)
AND sender = 'system' AND kind = 'scammer';

-- Scenario 4 (Phishing Email): same issue on B1.
UPDATE nodes SET kind = 'choice'
WHERE code = 'B1' AND scenario_id = (
  SELECT id FROM scenarios WHERE title = 'Phishing Email'
)
AND sender = 'system' AND kind = 'scammer';

-- Scenario 5 (Social-Media Account Recovery Scam): A1 has 2 choices leading to A1A,
-- so it must NOT be is_end. It's an intermediate system narration with choices.
UPDATE nodes SET is_end = false, kind = 'choice'
WHERE code = 'A1' AND scenario_id = (
  SELECT id FROM scenarios WHERE title = 'Social-Media Account Recovery Scam'
)
AND kind = 'end';
