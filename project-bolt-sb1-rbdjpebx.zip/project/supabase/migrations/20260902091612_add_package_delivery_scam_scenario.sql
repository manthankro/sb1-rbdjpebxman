/*
# CyberShield — add "Package Delivery Scam" scenario

Adds a realistic, commonly-encountered scam: an SMS claiming a package is on
hold at a courier warehouse, demanding a small "clearance fee" via a link.
Teaches users to never pay fees via SMS links and to verify through official
courier channels.
*/

DO $$
DECLARE
  sid uuid;
  n_start uuid; n_a1 uuid; n_b1 uuid; n_c1 uuid; n_c1a uuid; n_c1b uuid;
  n_d1 uuid; n_d1a uuid; n_d1b uuid; n_ft uuid;
BEGIN
  -- Remove prior version if re-run.
  DELETE FROM choices WHERE node_id IN (
    SELECT id FROM nodes WHERE scenario_id = (
      SELECT id FROM scenarios WHERE title = 'Package Delivery Scam'
    )
  );
  DELETE FROM nodes WHERE scenario_id = (
    SELECT id FROM scenarios WHERE title = 'Package Delivery Scam'
  );
  DELETE FROM scenarios WHERE title = 'Package Delivery Scam';

  INSERT INTO scenarios (title, category, difficulty, description, starting_score, active)
  VALUES ('Package Delivery Scam', 'Delivery Fraud', 'easy',
    'An SMS claims your package is on hold at a courier warehouse and you must pay a small clearance fee via a link to release it. Learn to spot fake courier messages and protect your card details.', 0, true)
  RETURNING id INTO sid;

  -- Nodes ------------------------------------------------------------------
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_start)
  VALUES (sid, 'START',
    'SMS from QuickParcel: Your package #QP8842 is held at our warehouse. Pay Rs.49 clearance fee within 12 hours or it will be returned to sender. Pay here: http://parceltrack.fake/pay',
    'scammer', 'scammer', true)
  RETURNING id INTO n_start;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'A1',
    'You paid Rs.49 on the fake page. The scammer captured your card details and later debited Rs.12,000. Small fees on fake courier pages are bait for bigger theft.',
    'system', 'end', true) RETURNING id INTO n_a1;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'B1',
    'You ignored and deleted the message. Since you never ordered anything, ignoring unsolicited delivery messages is the safest response.',
    'system', 'end', true) RETURNING id INTO n_b1;

  INSERT INTO nodes (scenario_id, code, message, sender, kind)
  VALUES (sid, 'C1',
    'You checked the official courier website — tracking number QP8842 does not exist. What do you do next?',
    'system', 'choice') RETURNING id INTO n_c1;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'C1A',
    'You reported the number to the national cyber portal and blocked it. Excellent — reporting protects others from the same scam.',
    'system', 'end', true) RETURNING id INTO n_c1a;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'C1B',
    'You went back and paid the fee anyway. The fake page captured your card details. Verifying the scam then ignoring your own verification still leads to harm.',
    'system', 'end', true) RETURNING id INTO n_c1b;

  INSERT INTO nodes (scenario_id, code, message, sender, kind)
  VALUES (sid, 'D1',
    'The scammer replies: "It is a high-value parcel — electronics worth Rs.15,000. The Rs.49 is just a clearance charge. Pay now at parceltrack.fake/pay before it is returned."',
    'scammer', 'scammer') RETURNING id INTO n_d1;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'D1A',
    'You paid the Rs.49 fee. The scammer now has your card details and debited more later. Engaging with a scammer then paying is a double mistake.',
    'system', 'end', true) RETURNING id INTO n_d1a;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'D1B',
    'You refused to pay and blocked the number. No legitimate courier demands payment via an SMS link. Well done.',
    'system', 'end', true) RETURNING id INTO n_d1b;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, next_node_id)
  VALUES (sid, 'FT',
    'In your own words, explain why a legitimate courier would never ask you to pay a clearance fee via a link in an SMS. Type your answer below.',
    'system', 'free_text', n_b1) RETURNING id INTO n_ft;

  -- Choices on START ------------------------------------------------------
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'A',
    'I''ll click the link and pay the Rs.49 fee to release my package.',
    60, n_a1,
    'Clicking an unknown link AND entering card details compounds two high-risk actions. Risk: click suspicious link (+25) + send money (+35).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'B',
    'I didn''t order anything. I''ll delete this message.',
    -15, n_b1,
    'Ignoring unsolicited delivery messages when you did not order anything is safe and practical. Risk: refuse engagement (-15).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'C',
    'I''ll check the official courier website with this tracking number.',
    -20, n_c1,
    'Verifying through the official courier site is the safest path. Risk: verify official source (-20).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'D',
    'What package is this? I''ll reply to ask.',
    10, n_d1,
    'Replying to a scammer confirms your number is active and invites more pressure. Risk: ignore warnings (+10).');

  -- Choices on C1 (verified — no such package) -----------------------------
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_c1, 'A',
    'This is a scam. I''ll report the number and block it.',
    -20, n_c1a,
    'Reporting and blocking protects you and others. Risk: report scam (-20).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_c1, 'B',
    'Maybe it''s still real. I''ll go pay the fee just in case.',
    60, n_c1b,
    'Paying after you already confirmed the tracking number is fake negates your good check. Risk: click link (+25) + send money (+35).');

  -- Choices on D1 (scammer pressures you) ----------------------------------
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_d1, 'A',
    'Okay, Rs.49 is small. I''ll pay.',
    35, n_d1a,
    'A small fee on a fake page captures your card for larger theft. Risk: send money (+35).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_d1, 'B',
    'No legitimate courier charges fees via SMS. I''m blocking this number.',
    -15, n_d1b,
    'Refusing to pay and blocking is the right response. Risk: refuse payment (-15).');
END $$;
