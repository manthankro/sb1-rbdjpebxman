/*
# CyberShield — AI-Based Adaptive Scam Conversation Simulator

## Purpose
Educational cybersecurity awareness platform. Students log in, pick a fictional scam
scenario, walk through a branching conversation, and receive a transparent risk score,
awareness score, AI/rule-based analysis of any free-text responses, and personalized
recommendations. Admins view aggregate analytics. All scenarios, identities, links, phone
numbers, and financial details are FICTIONAL test data — no real credentials, accounts,
people, or phishing links are used.

## Tables created
1. `profiles` — extends Supabase auth.users with a display name and role (student/admin).
2. `scenarios` — fictional scam scenarios (title, category, difficulty, description, active).
3. `nodes` — conversation nodes in a scenario tree (message, sender = scammer/student/system, kind).
4. `choices` — selectable responses on a node; each has risk_points, next_node_id, explanation.
5. `sessions` — a student's attempt at a scenario; final_score, awareness_score, result_level, difficulty.
6. `responses` — each decision the student made during a session (node_id, choice_id, free_text, risk_points, ai_analysis).
7. `recommendations` — personalized feedback rows attached to a session.
8. `scoring_rules` — configurable risk point values used by the scoring engine (admin-editable).

## Security
- RLS enabled on every table.
- `profiles`, `sessions`, `responses` are owner-scoped (authenticated, auth.uid() = user_id).
- `scenarios`, `nodes`, `choices`, `scoring_rules`, `recommendations` are readable by all
  authenticated users (shared educational content). Writes restricted to admins via a
  helper check on profiles.role = 'admin'. The app enforces role checks in the UI; policies
  additionally gate writes to scenarios/nodes/choices/scoring_rules to admin profiles.
- Owner columns default to auth.uid() so inserts that omit user_id still satisfy WITH CHECK.

## Notes
- This migration is idempotent (IF NOT EXISTS / DROP POLICY IF EXISTS).
- Scenarios/nodes/choices are seeded in a separate seed migration.
*/

-- 1. profiles ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL DEFAULT 'student' CHECK (role IN ('student','admin')),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Admins can read all profiles (for the admin dashboard student list).
DROP POLICY IF EXISTS "admin_read_all_profiles" ON profiles;
CREATE POLICY "admin_read_all_profiles" ON profiles FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- 2. scenarios --------------------------------------------------------------
CREATE TABLE IF NOT EXISTS scenarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  category text NOT NULL,
  difficulty text NOT NULL DEFAULT 'easy' CHECK (difficulty IN ('easy','medium','hard')),
  description text NOT NULL DEFAULT '',
  starting_score int NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE scenarios ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_active_scenarios" ON scenarios;
CREATE POLICY "read_active_scenarios" ON scenarios FOR SELECT
  TO authenticated USING (active = true);

DROP POLICY IF EXISTS "admin_read_all_scenarios" ON scenarios;
CREATE POLICY "admin_read_all_scenarios" ON scenarios FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_write_scenarios" ON scenarios;
CREATE POLICY "admin_write_scenarios" ON scenarios FOR ALL
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- 3. nodes ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS nodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scenario_id uuid NOT NULL REFERENCES scenarios(id) ON DELETE CASCADE,
  code text NOT NULL,
  message text NOT NULL,
  sender text NOT NULL CHECK (sender IN ('scammer','student','system')),
  kind text NOT NULL DEFAULT 'scammer' CHECK (kind IN ('scammer','choice','free_text','end')),
  is_start boolean NOT NULL DEFAULT false,
  is_end boolean NOT NULL DEFAULT false,
  next_node_id uuid REFERENCES nodes(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (scenario_id, code)
);
ALTER TABLE nodes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_nodes" ON nodes;
CREATE POLICY "read_nodes" ON nodes FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_write_nodes" ON nodes;
CREATE POLICY "admin_write_nodes" ON nodes FOR ALL
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

CREATE INDEX IF NOT EXISTS idx_nodes_scenario ON nodes(scenario_id);

-- 4. choices ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS choices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  node_id uuid NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
  code char(1) NOT NULL,
  choice_text text NOT NULL,
  risk_points int NOT NULL DEFAULT 0,
  next_node_id uuid REFERENCES nodes(id) ON DELETE SET NULL,
  explanation text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (node_id, code)
);
ALTER TABLE choices ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_choices" ON choices;
CREATE POLICY "read_choices" ON choices FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_write_choices" ON choices;
CREATE POLICY "admin_write_choices" ON choices FOR ALL
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

CREATE INDEX IF NOT EXISTS idx_choices_node ON choices(node_id);

-- 5. sessions ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  scenario_id uuid NOT NULL REFERENCES scenarios(id) ON DELETE CASCADE,
  difficulty text NOT NULL DEFAULT 'easy' CHECK (difficulty IN ('easy','medium','hard')),
  raw_score int NOT NULL DEFAULT 0,
  final_score numeric NOT NULL DEFAULT 0,
  awareness_score numeric NOT NULL DEFAULT 100,
  result_level text NOT NULL DEFAULT 'Excellent',
  safe_decisions int NOT NULL DEFAULT 0,
  risky_decisions int NOT NULL DEFAULT 0,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_sessions" ON sessions;
CREATE POLICY "select_own_sessions" ON sessions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_sessions" ON sessions;
CREATE POLICY "insert_own_sessions" ON sessions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_sessions" ON sessions;
CREATE POLICY "update_own_sessions" ON sessions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_sessions" ON sessions;
CREATE POLICY "delete_own_sessions" ON sessions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "admin_read_all_sessions" ON sessions;
CREATE POLICY "admin_read_all_sessions" ON sessions FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_scenario ON sessions(scenario_id);

-- 6. responses --------------------------------------------------------------
CREATE TABLE IF NOT EXISTS responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  node_id uuid NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
  choice_id uuid REFERENCES choices(id) ON DELETE SET NULL,
  choice_code text,
  free_text text,
  risk_points int NOT NULL DEFAULT 0,
  explanation text NOT NULL DEFAULT '',
  ai_analysis jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE responses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_responses" ON responses;
CREATE POLICY "select_own_responses" ON responses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_responses" ON responses;
CREATE POLICY "insert_own_responses" ON responses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_responses" ON responses;
CREATE POLICY "update_own_responses" ON responses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_responses" ON responses;
CREATE POLICY "delete_own_responses" ON responses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "admin_read_all_responses" ON responses;
CREATE POLICY "admin_read_all_responses" ON responses FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

CREATE INDEX IF NOT EXISTS idx_responses_session ON responses(session_id);

-- 7. recommendations --------------------------------------------------------
CREATE TABLE IF NOT EXISTS recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  recommendation text NOT NULL,
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high')),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE recommendations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_recommendations" ON recommendations;
CREATE POLICY "select_own_recommendations" ON recommendations FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_recommendations" ON recommendations;
CREATE POLICY "insert_own_recommendations" ON recommendations FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_read_all_recommendations" ON recommendations;
CREATE POLICY "admin_read_all_recommendations" ON recommendations FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

CREATE INDEX IF NOT EXISTS idx_recs_session ON recommendations(session_id);

-- 8. scoring_rules ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS scoring_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  label text NOT NULL,
  risk_points int NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE scoring_rules ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_scoring_rules" ON scoring_rules;
CREATE POLICY "read_scoring_rules" ON scoring_rules FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_write_scoring_rules" ON scoring_rules;
CREATE POLICY "admin_write_scoring_rules" ON scoring_rules FOR ALL
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- Trigger to keep updated_at fresh on scoring_rules.
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_scoring_rules_updated ON scoring_rules;
CREATE TRIGGER trg_scoring_rules_updated
BEFORE UPDATE ON scoring_rules
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- A convenience view for the admin dashboard: per-scenario stats.
CREATE OR REPLACE VIEW scenario_stats AS
SELECT
  s.id AS scenario_id,
  s.title,
  s.category,
  s.difficulty,
  COUNT(sess.id) AS attempt_count,
  COALESCE(ROUND(AVG(sess.awareness_score), 1), 0) AS avg_awareness,
  COALESCE(ROUND(AVG(sess.final_score), 1), 0) AS avg_risk
FROM scenarios s
LEFT JOIN sessions sess ON sess.scenario_id = s.id
GROUP BY s.id, s.title, s.category, s.difficulty;