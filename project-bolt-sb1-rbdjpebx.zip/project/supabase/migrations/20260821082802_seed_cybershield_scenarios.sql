/*
# CyberShield — seed fictional scenarios, nodes, choices, and scoring rules

## Purpose
Populates the database with fully fictional, educational scam scenarios so the app is
demonstrable immediately. No real banks, people, credentials, links, or phone numbers.

## Seeded content
- 10 configurable scoring rules
- 5 scenarios: fake job offer, UPI/payment refund, fake scholarship, phishing email,
  social-media account recovery. Each has a branching tree of nodes + choices with
  risk_points and explanations, and at least one free-text node where applicable.
- All identities (company names, senders, domains) are obviously fictional.

## Notes
- Uses DO $$ blocks per scenario to wire generated UUIDs into choices.
- Idempotent for demo/dev: deletes prior seeded rows before re-inserting.
*/

-- Scoring rules -------------------------------------------------------------
INSERT INTO scoring_rules (slug, label, risk_points) VALUES
  ('share_otp',                 'Share OTP / authentication code',         30),
  ('share_password',            'Share password or passphrase',            40),
  ('send_money',                'Send money / pay a fee',                   35),
  ('share_pii',                 'Share sensitive personal information',     30),
  ('click_suspicious_link',     'Click a suspicious link',                  25),
  ('ignore_warnings',           'Ignore warning signs',                     10),
  ('ask_verification',          'Ask for / demand verification',           -10),
  ('refuse_payment',            'Refuse to pay',                           -15),
  ('verify_official_source',    'Verify through an official source',       -20),
  ('report_scam',               'Report the scam',                         -20)
ON CONFLICT (slug) DO UPDATE SET label = EXCLUDED.label, risk_points = EXCLUDED.risk_points;

-- Clean any prior seed (dev/demo only) -------------------------------------
DELETE FROM choices WHERE node_id IN (SELECT id FROM nodes WHERE scenario_id IN (SELECT id FROM scenarios));
DELETE FROM nodes WHERE scenario_id IN (SELECT id FROM scenarios);
DELETE FROM scenarios;

-- =========================================================================
-- Scenario 1: Fake Job Offer
-- =========================================================================
DO $$
DECLARE
  sid uuid;
  n_start uuid; n_a1 uuid; n_a2 uuid; n_b1 uuid; n_b2 uuid; n_c1 uuid; n_d1 uuid;
BEGIN
  INSERT INTO scenarios (title, category, difficulty, description, starting_score, active)
  VALUES ('Fake Job Offer', 'Employment Scam', 'easy',
    'A recruiter messages you about a high-paying work-from-home job that requires an upfront registration fee. Learn to spot employment fraud.', 0, true)
  RETURNING id INTO sid;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_start)
  VALUES (sid, 'START', 'Hi! I am Riya from QuickCash Jobs. You have been selected for a Rs.40,000/month work-from-home data-entry job. Interested?', 'scammer', 'scammer', true)
  RETURNING id INTO n_start;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'A2', 'You paused and asked for verification. The "recruiter" stopped replying — a classic sign the offer was fake. Well done questioning it.', 'system', 'end', true) RETURNING id INTO n_a2;
  INSERT INTO nodes (scenario_id, code, message, sender, kind)
  VALUES (sid, 'A1', 'Great! Just pay a Rs.2,000 one-time registration fee to confirm your slot. It is fully refundable on your first salary.', 'scammer', 'scammer') RETURNING id INTO n_a1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind)
  VALUES (sid, 'B1', 'Perfect! Share your UPI ID and pay at payquick.fake/fee. Once paid, we will send your joining letter.', 'scammer', 'scammer') RETURNING id INTO n_b1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'B2', 'You paid the fee and shared payment details. Legitimate employers never charge upfront fees — you were scammed.', 'system', 'end', true) RETURNING id INTO n_b2;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'C1', 'You searched and found QuickCash Jobs has no official site, no reviews, and no company registration. You avoided a costly scam. Excellent.', 'system', 'end', true) RETURNING id INTO n_c1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'D1', 'You reported the message as scam/spam. Reporting protects you and others. Strong cyber-awareness behavior.', 'system', 'end', true) RETURNING id INTO n_d1;

  -- Choices on START
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'A', 'Please send me more information about the role.', 10, n_a1, 'Asking for more info is neutral, but engaging further without verifying keeps you on the scammer''s hook. Risk: ignoring warning signs (+10).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'B', 'Sure, I''ll pay the registration fee. Where do I send it?', 35, n_b1, 'Paying an upfront fee to a stranger is the core of employment fraud. Risk: send money (+35).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'C', 'I''ll verify the company through its official website first.', -20, n_c1, 'Verifying through an official, independent source is the safest action. Risk: verify official source (-20).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'D', 'This looks suspicious. I''m reporting it.', -20, n_d1, 'Reporting suspected scams protects the community. Risk: report scam (-20).');

  -- Choices on A1 (scammer asks for fee)
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_a1, 'A', 'Okay, here is my UPI ID. I''ll pay now.', 35, n_b2, 'You paid the fee and shared payment details — the scammer''s goal. Risk: send money (+35).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_a1, 'B', 'A refundable fee? I''ll verify your company before paying anything.', -10, n_a2, 'Demanding verification before paying is the right instinct. Risk: ask verification (-10).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_a1, 'C', 'No legitimate employer charges fees. I''m reporting this.', -20, n_d1, 'Recognizing the fee as a red flag and reporting is excellent. Risk: report scam (-20).');

  -- Choices on B1 (scammer pushes for payment)
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_b1, 'A', 'Here is my UPI ID: student@fakeupi. Paying now.', 35, n_b2, 'You completed the payment the scammer wanted. Risk: send money (+35).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_b1, 'B', 'Wait — I want to cancel. This feels off.', -15, n_a2, 'Refusing to pay and stepping back limits the damage. Risk: refuse payment (-15).');
END $$;

-- =========================================================================
-- Scenario 2: Fake UPI / Payment Refund Scam
-- =========================================================================
DO $$
DECLARE
  sid uuid;
  n_start uuid; n_a1 uuid; n_b1 uuid; n_c1 uuid; n_d1 uuid; n_d1a uuid; n_d1b uuid; n_ft uuid;
BEGIN
  INSERT INTO scenarios (title, category, difficulty, description, starting_score, active)
  VALUES ('Fake UPI / Payment Refund', 'Payment Scam', 'medium',
    'A caller claims a small refund is stuck and asks you to approve it on your UPI app — but "approving" a refund never requires sending money or an OTP.', 0, true)
  RETURNING id INTO sid;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_start)
  VALUES (sid, 'START', 'Hello, this is Customer Care from PayRefunds. Rs.499 is stuck in a failed transaction. To process your refund, please open your UPI app and tell me the 6-digit OTP you just received.', 'scammer', 'scammer', true)
  RETURNING id INTO n_start;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'A1', 'The scammer used your OTP to debit Rs.15,000 from your account. Sharing an OTP authorizes a transaction — never an incoming refund.', 'system', 'end', true) RETURNING id INTO n_a1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'B1', 'You refused to share the OTP and verified independently. Your money is safe. Excellent.', 'system', 'end', true) RETURNING id INTO n_b1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'C1', 'You recognized that refunds never need an OTP and reported the number. Strong awareness.', 'system', 'end', true) RETURNING id INTO n_c1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind)
  VALUES (sid, 'D1', 'Ma''am, I can give you my employee ID: PRF-9921. See, it''s genuine. Now please share the OTP so your refund isn''t cancelled.', 'scammer', 'scammer') RETURNING id INTO n_d1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'D1A', 'You pressed for verification and the caller became evasive and pressuring. You hung up and reported it. Well done not trusting an "employee ID".', 'system', 'end', true) RETURNING id INTO n_d1a;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'D1B', 'You accepted a made-up employee ID as proof and shared the OTP. An ID read over the phone proves nothing — your account was debited.', 'system', 'end', true) RETURNING id INTO n_d1b;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, next_node_id)
  VALUES (sid, 'FT', 'Explain in your own words why a refund would never require you to share an OTP. Type your answer below.', 'system', 'free_text', n_b1) RETURNING id INTO n_ft;

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'A', 'Sure, the OTP is 482713.', 30, n_a1, 'Sharing an OTP authorizes outgoing transactions — it never enables a refund. Risk: share OTP (+30).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'B', 'I don''t share OTPs with anyone. I''ll check my bank app directly.', -20, n_b1, 'Refusing the OTP and verifying through the official app is exactly right. Risk: verify official source (-20).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'C', 'Refunds don''t need an OTP. I''m hanging up and reporting this number.', -20, n_c1, 'Correct — and reporting protects others. Risk: report scam (-20).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'D', 'How do I know you''re really from PayRefunds?', -10, n_d1, 'Asking for verification is good, but stay alert: a caller reading an "ID" is not proof. Risk: ask verification (-10).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_d1, 'A', 'Okay, the OTP is 482713.', 30, n_a1, 'An "employee ID" over the phone is not verification. Sharing the OTP authorized the debit. Risk: share OTP (+30).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_d1, 'B', 'An employee ID isn''t proof. I''m hanging up and reporting this.', -20, n_d1a, 'You correctly judged phone-read IDs as meaningless and reported. Risk: report scam (-20).');
END $$;

-- =========================================================================
-- Scenario 3: Fake Scholarship
-- =========================================================================
DO $$
DECLARE
  sid uuid;
  n_start uuid; n_a1 uuid; n_b1 uuid; n_c1 uuid; n_d1 uuid; n_b1a uuid; n_b1b uuid;
BEGIN
  INSERT INTO scenarios (title, category, difficulty, description, starting_score, active)
  VALUES ('Fake Scholarship', 'Education Scam', 'medium',
    'An SMS claims you''ve won a government scholarship and must click a link and fill in your bank details to "claim" it. Learn to verify before you click.', 0, true)
  RETURNING id INTO sid;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_start)
  VALUES (sid, 'START', 'SMS from SCHOLAR-GOV: Congratulations! You have been selected for a Rs.25,000 national scholarship. Claim within 24 hours: http://scholarfund.fake/claim', 'scammer', 'scammer', true)
  RETURNING id INTO n_start;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'A1', 'The link led to a fake page that captured your bank details. Unsolicited "you won" messages with urgent links are a classic phishing pattern.', 'system', 'end', true) RETURNING id INTO n_a1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind)
  VALUES (sid, 'B1', 'Good instinct. The official portal shows no such scholarship under your name. What do you do next?', 'system', 'scammer') RETURNING id INTO n_b1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'C1', 'You recognized an unsolicited prize message as suspicious and ignored it. Smart — never engage with "you won" SMS from unknown sources.', 'system', 'end', true) RETURNING id INTO n_c1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'D1', 'You forwarded a phishing link to friends, exposing them too. Always verify before sharing suspicious messages — forwarding spreads the scam.', 'system', 'end', true) RETURNING id INTO n_d1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'B1A', 'You reported the SMS to the national cyber portal and warned your contacts. Excellent community-aware behavior.', 'system', 'end', true) RETURNING id INTO n_b1a;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'B1B', 'You went back and clicked the link anyway. The fake page captured your details. Verifying first, then ignoring your own verification, still leads to harm.', 'system', 'end', true) RETURNING id INTO n_b1b;

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'A', 'Wow, I''ll click the link and fill in my bank details to claim it.', 55, n_a1, 'Clicking an unknown link AND entering bank details compounds two high-risk actions. Risk: click suspicious link (+25) + share PII (+30).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'B', 'I''ll check the official government scholarship portal instead.', -20, n_b1, 'Verifying through the official portal is the safest path. Risk: verify official source (-20).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'C', 'I never applied for this. I''ll delete the SMS.', -15, n_c1, 'Ignoring unsolicited prize messages is safe and practical. Risk: refuse engagement (-15).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'D', 'Let me forward this to my friends so they can claim it too.', 30, n_d1, 'Forwarding an unverified phishing link spreads the scam to others. Risk: spread risk (+30).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_b1, 'A', 'It''s not real. I''ll report the SMS to the cyber portal and warn my contacts.', -20, n_b1a, 'Reporting and responsibly warning others is ideal. Risk: report scam (-20).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_b1, 'B', 'Still, maybe it''s real. I''ll click the link just in case.', 55, n_b1b, 'Clicking after you already verified it''s fake negates your good check. Risk: click link (+25) + share PII (+30).');
END $$;

-- =========================================================================
-- Scenario 4: Phishing Email
-- =========================================================================
DO $$
DECLARE
  sid uuid;
  n_start uuid; n_a1 uuid; n_b1 uuid; n_c1 uuid; n_d1 uuid; n_ft uuid; n_b1a uuid; n_b1b uuid;
BEGIN
  INSERT INTO scenarios (title, category, difficulty, description, starting_score, active)
  VALUES ('Phishing Email', 'Email Scam', 'easy',
    'An "account security" email urges you to reset your password via a link. Learn the signs of phishing: urgent tone, mismatched sender, suspicious links.', 0, true)
  RETURNING id INTO sid;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_start)
  VALUES (sid, 'START', 'From: security@verify-id.fake  |  Subject: Urgent — your account will be suspended in 24 hours. Click here to verify your identity now: http://verify-id.fake/reset', 'scammer', 'scammer', true)
  RETURNING id INTO n_start;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'A1', 'The fake page harvested your password. Urgent "suspend in 24h" language is designed to panic you into clicking — always pause.', 'system', 'end', true) RETURNING id INTO n_a1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind)
  VALUES (sid, 'B1', 'You hovered: the link points to verify-id.fake, not the real service domain, and the sender address is unrelated. What now?', 'system', 'scammer') RETURNING id INTO n_b1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'C1', 'You went straight to the official app and found no security alert. Using the official channel is the safest habit. Excellent.', 'system', 'end', true) RETURNING id INTO n_c1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'D1', 'Forwarding a phishing email spreads the risk. Report it to your mail provider instead of broadcasting the malicious link.', 'system', 'end', true) RETURNING id INTO n_d1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'B1A', 'You marked it as phishing and reported it. You protected yourself and helped train spam filters. Well done.', 'system', 'end', true) RETURNING id INTO n_b1a;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'B1B', 'You spotted the red flags but clicked anyway. Spotting a risk doesn''t help if you act on it — your password was captured.', 'system', 'end', true) RETURNING id INTO n_b1b;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, next_node_id)
  VALUES (sid, 'FT', 'In your own words, list two warning signs in this email that reveal it as phishing. Type your answer below.', 'system', 'free_text', n_c1) RETURNING id INTO n_ft;

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'A', 'I''ll click the link and enter my password to verify.', 65, n_a1, 'Clicking a suspicious link and entering your password gives attackers everything. Risk: click (+25) + share password (+40).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'B', 'I''ll hover over the link and check the sender address first.', -10, n_b1, 'Inspecting before clicking is a strong defensive habit. Risk: ask verification (-10).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'C', 'I''ll log in to the service directly via its official app, not this link.', -20, n_c1, 'Using the official channel bypasses the phishing link entirely. Risk: verify official source (-20).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'D', 'I''ll forward it to my whole contact list so everyone verifies.', 30, n_d1, 'Forwarding spreads the malicious link. Report instead of broadcasting. Risk: spread risk (+30).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_b1, 'A', 'It''s phishing. I''ll mark it as phishing and report it.', -20, n_b1a, 'Reporting trains filters and protects others. Risk: report scam (-20).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_b1, 'B', 'I''ll click it anyway, just to be sure.', 65, n_b1b, 'Clicking after spotting the red flags still hands over your password. Risk: click (+25) + share password (+40).');
END $$;

-- =========================================================================
-- Scenario 5: Social-Media Account Recovery Scam
-- =========================================================================
DO $$
DECLARE
  sid uuid;
  n_start uuid; n_a1 uuid; n_b1 uuid; n_c1 uuid; n_d1 uuid; n_d1a uuid; n_d1b uuid; n_a1a uuid;
BEGIN
  INSERT INTO scenarios (title, category, difficulty, description, starting_score, active)
  VALUES ('Social-Media Account Recovery Scam', 'Social Engineering', 'hard',
    'Someone pretending to be "Instagram Support" messages you, claiming your account will be suspended and asking for your password and a login code to "verify ownership". Learn to protect account credentials.', 0, true)
  RETURNING id INTO sid;

  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_start)
  VALUES (sid, 'START', 'DM from Instagram_Verify_Support: Your account violates our policy and will be suspended in 2 hours. To keep it, send your username, password, and the 6-digit login code we just texted you.', 'scammer', 'scammer', true)
  RETURNING id INTO n_start;

  INSERT INTO nodes (scenario_id, code, message, sender, kind)
  VALUES (sid, 'A1', 'The scammer logged in with your password and code, changed your recovery info, and locked you out. You handed over full account control.', 'system', 'end') RETURNING id INTO n_a1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'A1A', 'Final outcome: account compromised. Password + login code = full takeover. Use the official recovery flow to limit damage.', 'system', 'end', true) RETURNING id INTO n_a1a;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'B1', 'You recognized that platforms never ask for passwords and reported the impostor account. Excellent — this protects the community too.', 'system', 'end', true) RETURNING id INTO n_b1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'C1', 'You strengthened your account security instead of panicking. Changing the password and enabling 2FA is the ideal response.', 'system', 'end', true) RETURNING id INTO n_c1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind)
  VALUES (sid, 'D1', 'Calm down — we can stop the suspension. Just send the login code from your phone. Don''t worry about the password, the code is enough to "verify".', 'scammer', 'scammer') RETURNING id INTO n_d1;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'D1A', 'You refused the code and went to the official Help Center, which confirmed no suspension. You avoided a takeover by verifying independently.', 'system', 'end', true) RETURNING id INTO n_d1a;
  INSERT INTO nodes (scenario_id, code, message, sender, kind, is_end)
  VALUES (sid, 'D1B', 'You sent the login code. With it, the scammer completed a login and took over your account. A login code is a password — never share it.', 'system', 'end', true) RETURNING id INTO n_d1b;

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'A', 'Here is my password and the login code: 204881.', 70, n_a1, 'Sharing your password AND a login code hands over full account control. Risk: share password (+40) + share OTP (+30).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'B', 'Instagram never asks for passwords. I''ll report this account.', -20, n_b1, 'Recognizing the impostor and reporting is the best response. Risk: report scam (-20).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'C', 'I''ll change my password and turn on two-factor authentication.', -20, n_c1, 'Proactively strengthening security instead of complying is ideal. Risk: verify official source (-20).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_start, 'D', 'But my account will be suspended! How do I appeal?', 10, n_d1, 'Panicking and engaging keeps you on the hook. Urgency is a social-engineering tool. Risk: ignore warnings (+10).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_d1, 'A', 'Okay, the login code is 204881.', 30, n_d1b, 'A login code authorizes access just like an OTP. Sharing it = account takeover. Risk: share OTP (+30).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_d1, 'B', 'No — I''ll check the official Help Center myself.', -20, n_d1a, 'Verifying through the official Help Center defeats the scam. Risk: verify official source (-20).');

  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_a1, 'A', 'I''ll use the official account recovery flow immediately.', -10, n_a1a, 'Using official recovery limits further damage. Risk: verify official source (-10).');
  INSERT INTO choices (node_id, code, choice_text, risk_points, next_node_id, explanation)
  VALUES (n_a1, 'B', 'I''ll reply to the scammer and beg for my account back.', 10, n_a1a, 'Engaging further with the scammer won''t help and risks more manipulation. Risk: ignore warnings (+10).');
END $$;